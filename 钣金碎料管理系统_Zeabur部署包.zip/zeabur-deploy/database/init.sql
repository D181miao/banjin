-- ============================================================
-- 钣金碎料出入库管理系统 - 数据库建表脚本
-- Database: PostgreSQL 15+
-- Charset:  UTF-8
-- Version:  v1.0
-- Date:     2025-07-16
-- ============================================================

-- 清理（开发环境用，生产环境请勿执行）
-- DROP SCHEMA IF EXISTS public CASCADE;
-- CREATE SCHEMA public;

-- ============================================================
-- 1. 自定义 ENUM 类型
-- ============================================================

-- 用户角色
CREATE TYPE user_role AS ENUM ('viewer', 'operator', 'admin', 'super_admin');
COMMENT ON TYPE user_role IS '用户角色：operator=操作员, admin=管理员, super_admin=超级管理员';

-- 用户状态
CREATE TYPE user_status AS ENUM ('active', 'disabled');
COMMENT ON TYPE user_status IS '用户状态：active=启用, disabled=禁用';

-- 仓库布局类型
CREATE TYPE warehouse_layout_type AS ENUM ('standard', 'split_zone');
COMMENT ON TYPE warehouse_layout_type IS '仓库布局类型：standard=标准, split_zone=走廊分隔';

-- 库位状态
CREATE TYPE location_status AS ENUM ('empty', 'partial', 'full');
COMMENT ON TYPE location_status IS '库位状态：empty=空闲, partial=部分占用, full=已满';

-- 操作类型
CREATE TYPE operation_type AS ENUM ('inbound', 'outbound');
COMMENT ON TYPE operation_type IS '操作类型：inbound=入库, outbound=出库';

-- 操作模式
CREATE TYPE operation_mode AS ENUM ('append', 'overwrite', 'empty_in', 'partial_out', 'full_out');
COMMENT ON TYPE operation_mode IS '操作模式：append=追加入库, overwrite=覆盖入库, empty_in=空库入库, partial_out=部分出库, full_out=全部出库';

-- 同步操作类型
CREATE TYPE sync_operation AS ENUM ('insert', 'update', 'delete');
COMMENT ON TYPE sync_operation IS '同步操作类型';

-- ============================================================
-- 2. 全局同步版本号序列
-- ============================================================

CREATE SEQUENCE global_version_seq START WITH 1 INCREMENT BY 1;
COMMENT ON SEQUENCE global_version_seq IS '全局递增版本号序列，用于多端增量同步';

-- ============================================================
-- 3. 建表
-- ============================================================

-- -----------------------------------------------------------
-- 3.1 用户表 (users)
-- -----------------------------------------------------------
CREATE TABLE users (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    phone           VARCHAR(20)     NOT NULL,
    password_hash   VARCHAR(256)    NOT NULL,
    name            VARCHAR(50)     NOT NULL,
    avatar_url      VARCHAR(500),
    role            user_role       NOT NULL DEFAULT 'operator',
    status          user_status     NOT NULL DEFAULT 'active',
    last_login_at   TIMESTAMPTZ,
    last_login_ip   VARCHAR(45),
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    created_by      UUID            REFERENCES users(id) ON DELETE SET NULL,
    updated_by      UUID            REFERENCES users(id) ON DELETE SET NULL,

    CONSTRAINT uq_users_phone UNIQUE (phone)
);

COMMENT ON TABLE  users IS '用户表 - 系统用户与角色管理';
COMMENT ON COLUMN users.id IS '用户主键（UUID）';
COMMENT ON COLUMN users.phone IS '手机号，用于登录，全局唯一';
COMMENT ON COLUMN users.password_hash IS 'bcrypt 哈希密码，禁止明文存储';
COMMENT ON COLUMN users.name IS '用户姓名';
COMMENT ON COLUMN users.role IS '用户角色：operator/admin/super_admin';
COMMENT ON COLUMN users.status IS '用户状态：active=启用/disabled=禁用';

-- 索引
CREATE INDEX idx_users_phone  ON users (phone);
CREATE INDEX idx_users_role   ON users (role);
CREATE INDEX idx_users_status ON users (status);

-- -----------------------------------------------------------
-- 3.2 物料类型表 (material_types)
-- -----------------------------------------------------------
CREATE TABLE material_types (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    code            VARCHAR(20)     NOT NULL,
    name            VARCHAR(100)    NOT NULL,
    short_name      VARCHAR(20),
    description     TEXT,
    color           VARCHAR(7)      NOT NULL,
    unit            VARCHAR(10)     NOT NULL DEFAULT 'kg',
    sort_order      INT             NOT NULL DEFAULT 0,
    is_active       BOOLEAN         NOT NULL DEFAULT TRUE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    created_by      UUID            REFERENCES users(id) ON DELETE SET NULL,
    updated_by      UUID            REFERENCES users(id) ON DELETE SET NULL,

    CONSTRAINT uq_material_types_code UNIQUE (code)
);

COMMENT ON TABLE  material_types IS '物料类型表 - 定义5种物料类型';
COMMENT ON COLUMN material_types.code IS '物料编码，如 W01~W05';
COMMENT ON COLUMN material_types.name IS '物料名称，如"废钣金件碎料"';
COMMENT ON COLUMN material_types.short_name IS '简称，用于界面紧凑展示';
COMMENT ON COLUMN material_types.color IS '标识色（HEX），用于平面图色块渲染';
COMMENT ON COLUMN material_types.sort_order IS '排序权重，数值越小越靠前';
COMMENT ON COLUMN material_types.is_active IS '是否启用，软禁用无需删除数据';

-- 索引
CREATE INDEX idx_material_types_code   ON material_types (code);
CREATE INDEX idx_material_types_active ON material_types (is_active) WHERE is_active = TRUE;

-- -----------------------------------------------------------
-- 3.3 仓库表 (warehouses)
-- -----------------------------------------------------------
CREATE TABLE warehouses (
    id                      UUID                    PRIMARY KEY DEFAULT gen_random_uuid(),
    material_type_id        UUID                    NOT NULL REFERENCES material_types(id),
    code                    VARCHAR(20)             NOT NULL,
    name                    VARCHAR(100)            NOT NULL,
    rows                    INT                     NOT NULL,
    cols                    INT                     NOT NULL,
    total_slots             INT                     NOT NULL,
    layout_type             warehouse_layout_type   NOT NULL DEFAULT 'standard',
    layout_config           JSONB                   NOT NULL DEFAULT '{}',
    default_max_capacity    DECIMAL(10,1)           NOT NULL DEFAULT 1000.0,
    is_active               BOOLEAN                 NOT NULL DEFAULT TRUE,
    created_at              TIMESTAMPTZ             NOT NULL DEFAULT now(),
    updated_at              TIMESTAMPTZ             NOT NULL DEFAULT now(),
    created_by              UUID                    REFERENCES users(id) ON DELETE SET NULL,
    updated_by              UUID                    REFERENCES users(id) ON DELETE SET NULL,

    CONSTRAINT uq_warehouses_code            UNIQUE (code),
    CONSTRAINT uq_warehouses_material_type   UNIQUE (material_type_id),
    CONSTRAINT ck_warehouses_rows_positive   CHECK (rows > 0),
    CONSTRAINT ck_warehouses_cols_positive   CHECK (cols > 0),
    CONSTRAINT ck_warehouses_slots_positive  CHECK (total_slots > 0)
);

COMMENT ON TABLE  warehouses IS '仓库表 - 5个仓库及其布局配置';
COMMENT ON COLUMN warehouses.material_type_id IS '关联物料类型（1:1关系）';
COMMENT ON COLUMN warehouses.code IS '仓库编码：W01~W05';
COMMENT ON COLUMN warehouses.rows IS '仓库布局行数';
COMMENT ON COLUMN warehouses.cols IS '仓库布局列数';
COMMENT ON COLUMN warehouses.total_slots IS '总库位数（冗余字段，加速统计）';
COMMENT ON COLUMN warehouses.layout_type IS '布局类型：standard=标准布局, split_zone=走廊分隔';
COMMENT ON COLUMN warehouses.layout_config IS '特殊布局配置JSON，废包装皮仓库存左右分区信息';
COMMENT ON COLUMN warehouses.default_max_capacity IS '库位默认最大容量(kg)';

-- 索引
CREATE INDEX idx_warehouses_material_type ON warehouses (material_type_id);
CREATE INDEX idx_warehouses_active        ON warehouses (is_active) WHERE is_active = TRUE;

-- -----------------------------------------------------------
-- 3.4 库位表 (storage_locations)
-- -----------------------------------------------------------
CREATE TABLE storage_locations (
    id                      UUID                PRIMARY KEY DEFAULT gen_random_uuid(),
    warehouse_id            UUID                NOT NULL REFERENCES warehouses(id),
    row_num                 INT                 NOT NULL,
    col_num                 INT                 NOT NULL,
    zone                    VARCHAR(10)         NOT NULL DEFAULT 'main',
    location_code           VARCHAR(20)         NOT NULL,
    status                  location_status     NOT NULL DEFAULT 'empty',
    current_material_id     UUID                REFERENCES material_types(id),
    current_weight          DECIMAL(10,1)       NOT NULL DEFAULT 0.0,
    max_capacity            DECIMAL(10,1)       NOT NULL DEFAULT 1000.0,
    version                 INT                 NOT NULL DEFAULT 0,
    updated_at              TIMESTAMPTZ         NOT NULL DEFAULT now(),
    created_at              TIMESTAMPTZ         NOT NULL DEFAULT now(),

    CONSTRAINT uq_locations_code                     UNIQUE (location_code),
    CONSTRAINT uq_locations_warehouse_row_col_zone   UNIQUE (warehouse_id, row_num, col_num, zone),
    CONSTRAINT ck_locations_row_positive             CHECK (row_num > 0),
    CONSTRAINT ck_locations_col_positive             CHECK (col_num > 0),
    CONSTRAINT ck_locations_weight_non_negative      CHECK (current_weight >= 0),
    CONSTRAINT ck_locations_weight_within_capacity   CHECK (current_weight <= max_capacity),
    CONSTRAINT ck_locations_version_non_negative     CHECK (version >= 0)
);

COMMENT ON TABLE  storage_locations IS '库位表 - 140个库位的坐标、状态与库存';
COMMENT ON COLUMN storage_locations.warehouse_id IS '所属仓库';
COMMENT ON COLUMN storage_locations.row_num IS '行号（从1开始）';
COMMENT ON COLUMN storage_locations.col_num IS '列号（从1开始）';
COMMENT ON COLUMN storage_locations.zone IS '区域标识：main=标准, left=左区, right=右区（废包装皮用）';
COMMENT ON COLUMN storage_locations.location_code IS '库位编码，格式如 W01-R3C5';
COMMENT ON COLUMN storage_locations.status IS '库位状态：empty=空闲, partial=部分占用, full=已满';
COMMENT ON COLUMN storage_locations.current_material_id IS '当前存放物料类型，NULL表示空闲';
COMMENT ON COLUMN storage_locations.current_weight IS '当前存放重量(kg)';
COMMENT ON COLUMN storage_locations.max_capacity IS '最大容量(kg)';
COMMENT ON COLUMN storage_locations.version IS '乐观锁版本号，用于并发控制';

-- 索引
CREATE INDEX idx_locations_warehouse         ON storage_locations (warehouse_id);
CREATE INDEX idx_locations_warehouse_status  ON storage_locations (warehouse_id, status);
CREATE INDEX idx_locations_material          ON storage_locations (current_material_id) WHERE current_material_id IS NOT NULL;
CREATE INDEX idx_locations_code              ON storage_locations (location_code);
CREATE INDEX idx_locations_zone              ON storage_locations (warehouse_id, zone);

-- -----------------------------------------------------------
-- 3.5 操作日志表 (operation_logs) - 按月分区
-- -----------------------------------------------------------
CREATE TABLE operation_logs (
    id                          UUID                NOT NULL DEFAULT gen_random_uuid(),
    user_id                     UUID                NOT NULL REFERENCES users(id),
    operation_type              operation_type       NOT NULL,
    warehouse_id                UUID                NOT NULL REFERENCES warehouses(id),
    location_id                 UUID                NOT NULL REFERENCES storage_locations(id),
    material_type_id            UUID                NOT NULL REFERENCES material_types(id),
    weight                      DECIMAL(10,1)       NOT NULL,
    mode                        operation_mode       NOT NULL,
    location_weight_before      DECIMAL(10,1)       NOT NULL,
    location_weight_after       DECIMAL(10,1)       NOT NULL,
    material_before             UUID,
    remark                      TEXT,
    device_info                 VARCHAR(200),
    ip_address                  VARCHAR(45),
    created_at                  TIMESTAMPTZ         NOT NULL DEFAULT now(),

    CONSTRAINT pk_operation_logs PRIMARY KEY (id, created_at)
) PARTITION BY RANGE (created_at);

COMMENT ON TABLE  operation_logs IS '操作日志表 - 记录每次出入库操作，不可修改不可删除（按月分区）';
COMMENT ON COLUMN operation_logs.operation_type IS '操作类型：inbound=入库, outbound=出库';
COMMENT ON COLUMN operation_logs.weight IS '本次操作重量(kg)';
COMMENT ON COLUMN operation_logs.mode IS '操作模式：append/overwrite/empty_in/partial_out/full_out';
COMMENT ON COLUMN operation_logs.location_weight_before IS '操作前库位重量(kg)';
COMMENT ON COLUMN operation_logs.location_weight_after IS '操作后库位重量(kg)';
COMMENT ON COLUMN operation_logs.material_before IS '操作前物料类型（覆盖模式时记录原物料）';
COMMENT ON COLUMN operation_logs.device_info IS '操作设备信息（UA字符串）';

-- 按月创建分区（示例：2025年7月~12月）
CREATE TABLE operation_logs_2025_07 PARTITION OF operation_logs
    FOR VALUES FROM ('2025-07-01') TO ('2025-08-01');
CREATE TABLE operation_logs_2025_08 PARTITION OF operation_logs
    FOR VALUES FROM ('2025-08-01') TO ('2025-09-01');
CREATE TABLE operation_logs_2025_09 PARTITION OF operation_logs
    FOR VALUES FROM ('2025-09-01') TO ('2025-10-01');
CREATE TABLE operation_logs_2025_10 PARTITION OF operation_logs
    FOR VALUES FROM ('2025-10-01') TO ('2025-11-01');
CREATE TABLE operation_logs_2025_11 PARTITION OF operation_logs
    FOR VALUES FROM ('2025-11-01') TO ('2025-12-01');
CREATE TABLE operation_logs_2025_12 PARTITION OF operation_logs
    FOR VALUES FROM ('2025-12-01') TO ('2026-01-01');

-- 索引（分区表上创建的索引会自动应用到各分区）
CREATE INDEX idx_oplogs_created_at      ON operation_logs (created_at DESC);
CREATE INDEX idx_oplogs_user            ON operation_logs (user_id);
CREATE INDEX idx_oplogs_warehouse       ON operation_logs (warehouse_id);
CREATE INDEX idx_oplogs_location        ON operation_logs (location_id);
CREATE INDEX idx_oplogs_material        ON operation_logs (material_type_id);
CREATE INDEX idx_oplogs_type_time       ON operation_logs (operation_type, created_at DESC);
CREATE INDEX idx_oplogs_user_time       ON operation_logs (user_id, created_at DESC);

-- -----------------------------------------------------------
-- 3.6 系统配置表 (system_configs)
-- -----------------------------------------------------------
CREATE TABLE system_configs (
    id              UUID            PRIMARY KEY DEFAULT gen_random_uuid(),
    config_key      VARCHAR(100)    NOT NULL,
    config_value    JSONB           NOT NULL DEFAULT '{}',
    config_type     VARCHAR(20)     NOT NULL DEFAULT 'string',
    description     VARCHAR(500),
    is_public       BOOLEAN         NOT NULL DEFAULT FALSE,
    created_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    updated_at      TIMESTAMPTZ     NOT NULL DEFAULT now(),
    created_by      UUID            REFERENCES users(id) ON DELETE SET NULL,
    updated_by      UUID            REFERENCES users(id) ON DELETE SET NULL,

    CONSTRAINT uq_system_configs_key UNIQUE (config_key)
);

COMMENT ON TABLE  system_configs IS '系统配置表 - 支持热更新的系统参数';
COMMENT ON COLUMN system_configs.config_key IS '配置键名，全局唯一';
COMMENT ON COLUMN system_configs.config_value IS '配置值（JSON格式）';
COMMENT ON COLUMN system_configs.config_type IS '值类型提示：string/number/boolean/json';
COMMENT ON COLUMN system_configs.is_public IS '是否允许前端读取（非公开配置仅后端使用）';

-- 索引
CREATE INDEX idx_configs_key ON system_configs (config_key);

-- -----------------------------------------------------------
-- 3.7 同步版本表 (sync_versions)
-- -----------------------------------------------------------
CREATE TABLE sync_versions (
    id              UUID                PRIMARY KEY DEFAULT gen_random_uuid(),
    table_name      VARCHAR(50)         NOT NULL,
    record_id       UUID                NOT NULL,
    version         BIGINT              NOT NULL DEFAULT nextval('global_version_seq'),
    operation       sync_operation      NOT NULL,
    changed_fields  TEXT[],
    created_at      TIMESTAMPTZ         NOT NULL DEFAULT now(),

    CONSTRAINT ck_sync_version_positive CHECK (version > 0)
);

COMMENT ON TABLE  sync_versions IS '同步版本表 - 多端实时同步变更追踪';
COMMENT ON COLUMN sync_versions.table_name IS '发生变更的表名';
COMMENT ON COLUMN sync_versions.record_id IS '变更记录的主键ID';
COMMENT ON COLUMN sync_versions.version IS '全局递增版本号，由序列生成';
COMMENT ON COLUMN sync_versions.operation IS '操作类型：insert/update/delete';
COMMENT ON COLUMN sync_versions.changed_fields IS '变更字段列表（数组），用于客户端精准更新';

-- 索引
CREATE INDEX idx_sync_version        ON sync_versions (version);
CREATE INDEX idx_sync_table_version  ON sync_versions (table_name, version);
CREATE INDEX idx_sync_created_at     ON sync_versions (created_at);

-- ============================================================
-- 4. 触发器：自动更新 updated_at
-- ============================================================

-- 通用 updated_at 触发器函数
CREATE OR REPLACE FUNCTION trigger_set_updated_at()
RETURNS TRIGGER AS $$
BEGIN
    NEW.updated_at = now();
    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

COMMENT ON FUNCTION trigger_set_updated_at() IS '自动更新 updated_at 字段的触发器函数';

-- 应用到各表
CREATE TRIGGER set_updated_at BEFORE UPDATE ON users
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON material_types
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON warehouses
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON storage_locations
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

CREATE TRIGGER set_updated_at BEFORE UPDATE ON system_configs
    FOR EACH ROW EXECUTE FUNCTION trigger_set_updated_at();

-- ============================================================
-- 5. 触发器：操作日志自动写入 sync_versions
-- ============================================================

-- storage_locations 变更后自动记录同步版本
CREATE OR REPLACE FUNCTION trigger_sync_storage_locations()
RETURNS TRIGGER AS $$
DECLARE
    v_changed_fields TEXT[];
BEGIN
    -- 计算变更字段
    v_changed_fields := ARRAY[]::TEXT[];
    IF OLD.status IS DISTINCT FROM NEW.status THEN
        v_changed_fields := array_append(v_changed_fields, 'status');
    END IF;
    IF OLD.current_material_id IS DISTINCT FROM NEW.current_material_id THEN
        v_changed_fields := array_append(v_changed_fields, 'current_material_id');
    END IF;
    IF OLD.current_weight IS DISTINCT FROM NEW.current_weight THEN
        v_changed_fields := array_append(v_changed_fields, 'current_weight');
    END IF;
    IF OLD.version IS DISTINCT FROM NEW.version THEN
        v_changed_fields := array_append(v_changed_fields, 'version');
    END IF;

    INSERT INTO sync_versions (table_name, record_id, operation, changed_fields)
    VALUES ('storage_locations', NEW.id, 'update', v_changed_fields);

    RETURN NEW;
END;
$$ LANGUAGE plpgsql;

CREATE TRIGGER sync_storage_locations AFTER UPDATE ON storage_locations
    FOR EACH ROW EXECUTE FUNCTION trigger_sync_storage_locations();

-- ============================================================
-- 6. 初始数据
-- ============================================================

-- 6.1 创建默认超级管理员（密码: admin123 的 bcrypt 哈希）
INSERT INTO users (phone, password_hash, name, role, status)
VALUES (
    '13800000000',
    '$2b$12$LJ3m4ys3uz0E8MzVCsGp8eFZ1Q2h5K6G5f3X8y1A2B3C4D5E6F7G8',
    '系统管理员',
    'super_admin',
    'active'
);

-- 6.2 物料类型
INSERT INTO material_types (code, name, short_name, description, color, sort_order) VALUES
    ('W01', '废钣金件碎料',   '碎料',   '钣金加工产生的碎料废料',     '#E74C3C', 1),
    ('W02', '废钣金件小圆饼', '小圆饼', '冲压产生的小尺寸圆饼废料',   '#F39C12', 2),
    ('W03', '废钣金件大圆饼', '大圆饼', '冲压产生的大尺寸圆饼废料',   '#2ECC71', 3),
    ('W04', '废包装皮',       '包装皮', '拆卸后的废旧包装外皮',       '#3498DB', 4),
    ('W05', '废钣金件打边料', '打边料', '钣金件边缘修剪产生的废料',   '#9B59B6', 5);

-- 6.3 仓库
INSERT INTO warehouses (material_type_id, code, name, rows, cols, total_slots, layout_type, layout_config)
SELECT
    mt.id,
    mt.code,
    CASE mt.code
        WHEN 'W01' THEN '废钣金件碎料仓'
        WHEN 'W02' THEN '废钣金件小圆饼仓'
        WHEN 'W03' THEN '废钣金件大圆饼仓'
        WHEN 'W04' THEN '废包装皮仓'
        WHEN 'W05' THEN '废钣金件打边料仓'
    END,
    CASE mt.code WHEN 'W01' THEN 6 WHEN 'W02' THEN 2 WHEN 'W03' THEN 2 WHEN 'W04' THEN 4 WHEN 'W05' THEN 2 END,
    CASE mt.code WHEN 'W01' THEN 10 WHEN 'W02' THEN 4 WHEN 'W03' THEN 4 WHEN 'W04' THEN 8 WHEN 'W05' THEN 10 END,
    CASE mt.code WHEN 'W01' THEN 60 WHEN 'W02' THEN 8 WHEN 'W03' THEN 8 WHEN 'W04' THEN 44 WHEN 'W05' THEN 20 END,
    CASE mt.code WHEN 'W04' THEN 'split_zone'::warehouse_layout_type ELSE 'standard'::warehouse_layout_type END,
    CASE mt.code
        WHEN 'W04' THEN '{
            "type": "split_zone",
            "divider": "corridor",
            "zones": [
                {"zone": "left",  "label": "左区", "rows": 4, "cols": 8, "slot_count": 32, "start_row": 1, "start_col": 1},
                {"zone": "right", "label": "右区", "rows": 3, "cols": 4, "slot_count": 12, "start_row": 1, "start_col": 1}
            ]
        }'::jsonb
        ELSE ('{
            "type": "standard",
            "zones": [
                {"zone": "main", "label": "主区", "rows": ' || (CASE mt.code WHEN 'W01' THEN 6 WHEN 'W02' THEN 2 WHEN 'W03' THEN 2 WHEN 'W05' THEN 2 END) || ', "cols": ' || (CASE mt.code WHEN 'W01' THEN 10 WHEN 'W02' THEN 4 WHEN 'W03' THEN 4 WHEN 'W05' THEN 10 END) || ', "slot_count": ' || (CASE mt.code WHEN 'W01' THEN 60 WHEN 'W02' THEN 8 WHEN 'W03' THEN 8 WHEN 'W05' THEN 20 END) || '}
            ]
        }')::jsonb
    END
FROM material_types mt
ORDER BY mt.sort_order;

-- 6.4 库位（通过函数批量生成 140 个库位）
CREATE OR REPLACE FUNCTION generate_storage_locations()
RETURNS void AS $$
DECLARE
    v_warehouse RECORD;
    v_row INT;
    v_col INT;
    v_zone VARCHAR(10);
    v_location_code VARCHAR(20);
    v_counter INT;
BEGIN
    FOR v_warehouse IN SELECT * FROM warehouses ORDER BY code LOOP

        IF v_warehouse.layout_type = 'split_zone' THEN
            -- 废包装皮仓库：左区 4行8列 + 右区 3行4列
            v_counter := 0;

            -- 左区
            FOR v_row IN 1..4 LOOP
                FOR v_col IN 1..8 LOOP
                    v_counter := v_counter + 1;
                    v_location_code := v_warehouse.code || '-L' || v_row || 'C' || v_col;
                    INSERT INTO storage_locations (warehouse_id, row_num, col_num, zone, location_code, max_capacity)
                    VALUES (v_warehouse.id, v_row, v_col, 'left', v_location_code, v_warehouse.default_max_capacity);
                END LOOP;
            END LOOP;

            -- 右区
            FOR v_row IN 1..3 LOOP
                FOR v_col IN 1..4 LOOP
                    v_counter := v_counter + 1;
                    v_location_code := v_warehouse.code || '-R' || v_row || 'C' || v_col;
                    INSERT INTO storage_locations (warehouse_id, row_num, col_num, zone, location_code, max_capacity)
                    VALUES (v_warehouse.id, v_row, v_col, 'right', v_location_code, v_warehouse.default_max_capacity);
                END LOOP;
            END LOOP;

        ELSE
            -- 标准仓库
            FOR v_row IN 1..v_warehouse.rows LOOP
                FOR v_col IN 1..v_warehouse.cols LOOP
                    v_location_code := v_warehouse.code || '-R' || v_row || 'C' || v_col;
                    INSERT INTO storage_locations (warehouse_id, row_num, col_num, zone, location_code, max_capacity)
                    VALUES (v_warehouse.id, v_row, v_col, 'main', v_location_code, v_warehouse.default_max_capacity);
                END LOOP;
            END LOOP;
        END IF;

    END LOOP;
END;
$$ LANGUAGE plpgsql;

-- 执行库位生成
SELECT generate_storage_locations();

-- 6.5 系统配置
INSERT INTO system_configs (config_key, config_value, config_type, description, is_public) VALUES
    ('max_offline_cache',      '50',       'number',  '离线操作最大缓存笔数',               TRUE),
    ('sync_interval_ms',       '3000',     'number',  '同步心跳间隔(ms)',                    TRUE),
    ('default_max_capacity',   '1000.0',   'number',  '库位默认最大容量(kg)',               TRUE),
    ('token_expire_minutes',   '1440',     'number',  'JWT Token有效期(分钟)',               FALSE),
    ('weight_precision',       '1',        'number',  '重量小数位精度',                      TRUE),
    ('enable_push_notification','true',    'boolean', '是否启用消息推送',                     TRUE),
    ('conflict_retry_count',   '3',        'number',  '并发冲突自动重试次数',                TRUE);

-- ============================================================
-- 7. 数据验证查询（部署后检查）
-- ============================================================

-- 检查物料类型数量（应为5）
-- SELECT COUNT(*) AS material_type_count FROM material_types;

-- 检查仓库数量（应为5）
-- SELECT COUNT(*) AS warehouse_count FROM warehouses;

-- 检查库位总数（应为140）
-- SELECT COUNT(*) AS total_locations FROM storage_locations;

-- 检查各仓库库位数
-- SELECT w.code, w.name, COUNT(sl.id) AS slot_count
-- FROM warehouses w
-- LEFT JOIN storage_locations sl ON sl.warehouse_id = w.id
-- GROUP BY w.code, w.name
-- ORDER BY w.code;

-- 预期结果：
-- W01 | 废钣金件碎料仓   | 60
-- W02 | 废钣金件小圆饼仓 | 8
-- W03 | 废钣金件大圆饼仓 | 8
-- W04 | 废包装皮仓       | 44
-- W05 | 废钣金件打边料仓 | 20
-- 合计 = 140

-- ============================================================
-- 脚本结束
-- ============================================================
