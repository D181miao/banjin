# 钣金碎料管理系统 - Zeabur 部署版

基于 Node.js + Express + PostgreSQL 的钣金碎料出入库管理系统。

## 功能特性

- 碎料入库（空库入库、追加入库、覆盖入库）
- 碎料出库（单库位出库、批量出库）
- 库位实时状态展示（网格视图）
- 多仓库管理
- 物料类型管理（金属材质 + 颜色）
- 用户权限管理（超级管理员 / 管理员 / 操作员 / 查看者）
- WebSocket 实时数据同步
- 操作日志记录
- 数据看板与统计

## 技术栈

- 后端：Node.js + Express + TypeScript
- 数据库：PostgreSQL（推荐 Neon.tech）
- 实时通信：WebSocket (ws)
- 前端：单文件 SPA（原生 HTML/CSS/JS）

## Zeabur 部署步骤

### 1. 准备工作

- 准备一个 GitHub 账号
- 准备一个 PostgreSQL 数据库（推荐 [Neon.tech](https://neon.tech)，免费额度足够）
- 获取数据库连接字符串，格式如：`postgresql://user:password@host.neon.tech/neondb?sslmode=require`

### 2. 上传代码到 GitHub

将本项目上传到你的 GitHub 仓库：

```bash
git init
git add .
git commit -m "initial commit"
git remote add origin https://github.com/你的用户名/sheet-metal-scrap.git
git push -u origin main
```

### 3. 在 Zeabur 部署

1. 打开 [https://zeabur.com](https://zeabur.com)，用邮箱注册并登录
2. 点击 **Deploy New Service** → 选择 **Git** → 选择你的 GitHub 仓库
3. Zeabur 会自动检测为 Node.js 项目
4. 在 **Variables**（环境变量）中添加：

| 变量名 | 值 | 说明 |
|--------|-----|------|
| `DATABASE_URL` | `postgresql://user:pass@host.neon.tech/neondb?sslmode=require` | Neon 数据库连接串 |
| `JWT_SECRET` | 一个随机长字符串 | JWT 签名密钥 |
| `NODE_ENV` | `production` | 生产环境 |
| `PORT` | `8080` | 服务端口（Zeabur 默认） |

5. 点击 **Deploy**，等待部署完成
6. 部署完成后，点击生成的域名即可访问

### 4. 首次启动

服务首次启动时会自动：
- 创建数据库表结构
- 创建默认用户账号
- 生成库位数据

**默认账号：**

| 角色 | 手机号 | 密码 |
|------|--------|------|
| 超级管理员 | 181 | 123456 |
| 操作员 | 110003199 | 123456 |

> ⚠️ 请登录后立即修改默认密码！

## 本地开发

```bash
# 安装依赖
npm install

# 设置环境变量
export DATABASE_URL="postgresql://..."

# 开发模式运行
npm run dev

# 手动初始化数据库（可选，服务启动时会自动初始化）
npm run db:init

# 构建生产版本
npm run build
npm start
```

## 环境变量说明

| 变量 | 必填 | 默认值 | 说明 |
|------|------|--------|------|
| `DATABASE_URL` | ✅ | - | PostgreSQL 连接字符串 |
| `JWT_SECRET` | 推荐 | dev默认值 | JWT 签名密钥 |
| `NODE_ENV` | - | development | 运行环境 |
| `PORT` | - | 3000 | 服务端口 |
| `CORS_ORIGIN` | - | * | 允许的跨域来源 |
| `LOG_LEVEL` | - | info | 日志级别 |

## 项目结构

```
├── src/
│   ├── server.ts          # 服务入口
│   ├── config/            # 配置（数据库、环境变量）
│   ├── controllers/       # 控制器
│   ├── middleware/        # 中间件（认证、错误处理等）
│   ├── models/            # 数据模型
│   ├── routes/            # 路由定义
│   ├── services/          # 业务逻辑
│   ├── types/             # TypeScript 类型
│   ├── utils/             # 工具函数
│   └── websocket/         # WebSocket 管理
├── web/
│   └── index.html         # 前端单页应用
├── database/
│   ├── init.sql           # 建表 SQL
│   └── schema.sql         # Schema 定义
├── scripts/
│   └── db-init.ts         # 数据库初始化脚本
├── package.json
├── tsconfig.json
└── README.md
```
