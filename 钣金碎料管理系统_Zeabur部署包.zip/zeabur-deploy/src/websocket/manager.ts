// src/websocket/manager.ts - WebSocket 管理器（Zeabur 支持 WebSocket）

import { WebSocketServer, WebSocket } from 'ws';
import { Server } from 'http';
import { env } from '../config/env';

interface ClientInfo {
  ws: WebSocket;
  userId: string;
}

class WebSocketManager {
  private wss: WebSocketServer | null = null;
  private clients: Map<WebSocket, ClientInfo> = new Map();

  init(server: Server) {
    this.wss = new WebSocketServer({ server, path: env.ws.path });

    this.wss.on('connection', (ws: WebSocket) => {
      this.clients.set(ws, { ws, userId: '' });

      ws.on('message', (raw: Buffer) => {
        try {
          const msg = JSON.parse(raw.toString());
          if (msg.type === 'subscribe' && msg.userId) {
            const info = this.clients.get(ws);
            if (info) info.userId = msg.userId;
          }
        } catch {
          // ignore malformed messages
        }
      });

      ws.on('close', () => {
        this.clients.delete(ws);
      });

      ws.on('error', () => {
        this.clients.delete(ws);
      });
    });

    console.log(`✅ WebSocket 服务已启动 (path: ${env.ws.path})`);
  }

  broadcastToAll(data: string) {
    if (!this.wss) return;
    for (const [ws] of this.clients) {
      if (ws.readyState === WebSocket.OPEN) {
        try { ws.send(data); } catch {}
      }
    }
  }

  broadcastToUser(userId: string, data: string) {
    if (!this.wss) return;
    for (const [, info] of this.clients) {
      if (info.userId === userId && info.ws.readyState === WebSocket.OPEN) {
        try { info.ws.send(data); } catch {}
      }
    }
  }

  getConnectedCount(): number {
    return this.clients.size;
  }

  shutdown() {
    if (this.wss) {
      this.wss.close();
      this.wss = null;
    }
    this.clients.clear();
  }
}

export const wsManager = new WebSocketManager();
