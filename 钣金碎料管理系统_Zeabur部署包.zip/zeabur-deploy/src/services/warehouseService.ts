// src/services/warehouseService.ts - 仓库服务

import { query } from '../config/database';
import { NotFoundError } from '../utils/errors';

export class WarehouseService {
  async findAll() {
    const result = await query(
      `SELECT 
        w.id, w.code, w.name, w.rows, w.cols, w.total_slots,
        w.layout_type, w.layout_config, w.default_max_capacity, w.is_active,
        w.material_type_id,
        mt.code AS material_code, mt.name AS material_name, mt.color AS material_color,
        (SELECT COUNT(*) FROM storage_locations sl WHERE sl.warehouse_id = w.id) AS actual_slots,
        (SELECT COUNT(*) FROM storage_locations sl WHERE sl.warehouse_id = w.id AND sl.status != 'empty') AS occupied_slots
       FROM warehouses w
       JOIN material_types mt ON mt.id = w.material_type_id
       WHERE w.is_active = TRUE
       ORDER BY mt.sort_order ASC`
    );
    return result.rows;
  }

  async findById(id: string) {
    const result = await query(
      `SELECT 
        w.id, w.code, w.name, w.rows, w.cols, w.total_slots,
        w.layout_type, w.layout_config, w.default_max_capacity, w.is_active,
        w.material_type_id,
        mt.code AS material_code, mt.name AS material_name, mt.color AS material_color,
        mt.short_name AS material_short_name, mt.unit AS material_unit
       FROM warehouses w
       JOIN material_types mt ON mt.id = w.material_type_id
       WHERE w.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      throw new NotFoundError('仓库不存在');
    }

    return result.rows[0];
  }

  async getLocations(warehouseId: string) {
    // 验证仓库存在
    const warehouse = await this.findById(warehouseId);

    const result = await query(
      `SELECT 
        sl.id, sl.row_num, sl.col_num, sl.zone, sl.location_code,
        sl.status, sl.current_material_id, sl.current_weight, sl.max_capacity,
        sl.version, sl.updated_at,
        mt.name AS material_name, mt.short_name AS material_short_name, mt.color AS material_color
       FROM storage_locations sl
       LEFT JOIN material_types mt ON mt.id = sl.current_material_id
       WHERE sl.warehouse_id = $1
       ORDER BY sl.zone, sl.row_num, sl.col_num`,
      [warehouseId]
    );

    return {
      warehouse,
      locations: result.rows,
    };
  }
}

export const warehouseService = new WarehouseService();
