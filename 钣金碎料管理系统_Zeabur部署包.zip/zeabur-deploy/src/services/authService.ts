// src/services/authService.ts - 认证服务

import bcrypt from 'bcryptjs';
import jwt from 'jsonwebtoken';
import { query } from '../config/database';
import { env } from '../config/env';
import { UserStatus, UserRole } from '../types';
import { UnauthorizedError, BadRequestError } from '../utils/errors';

export class AuthService {
  async login(phone: string, password: string, ip?: string) {
    // 查找用户
    const userResult = await query(
      'SELECT id, phone, password_hash, name, role, status FROM users WHERE phone = $1',
      [phone]
    );

    if (userResult.rows.length === 0) {
      throw new UnauthorizedError('手机号或密码错误');
    }

    const user = userResult.rows[0];

    // 检查用户状态
    if (user.status !== UserStatus.ACTIVE) {
      throw new UnauthorizedError('账号已被禁用，请联系管理员');
    }

    // 验证密码
    const isValid = await bcrypt.compare(password, user.password_hash);
    if (!isValid) {
      throw new UnauthorizedError('手机号或密码错误');
    }

    // 生成 Token
    const accessToken = this.generateAccessToken(user);
    const refreshToken = this.generateRefreshToken(user);

    // 更新最后登录信息
    await query(
      'UPDATE users SET last_login_at = now(), last_login_ip = $1 WHERE id = $2',
      [ip, user.id]
    );

    return {
      accessToken,
      refreshToken,
      user: {
        id: user.id,
        phone: user.phone,
        name: user.name,
        role: user.role,
      },
    };
  }

  async refresh(refreshToken: string) {
    try {
      const decoded = jwt.verify(refreshToken, env.jwt.secret) as any;
      
      // 验证用户仍然有效
      const userResult = await query(
        'SELECT id, phone, name, role, status FROM users WHERE id = $1 AND status = $2',
        [decoded.userId, UserStatus.ACTIVE]
      );

      if (userResult.rows.length === 0) {
        throw new UnauthorizedError('用户不存在或已被禁用');
      }

      const user = userResult.rows[0];
      const newAccessToken = this.generateAccessToken(user);
      const newRefreshToken = this.generateRefreshToken(user);

      return { accessToken: newAccessToken, refreshToken: newRefreshToken };
    } catch (error) {
      if (error instanceof UnauthorizedError) throw error;
      throw new UnauthorizedError('刷新令牌无效或已过期');
    }
  }

  private generateAccessToken(user: any): string {
    return jwt.sign(
      {
        userId: user.id,
        phone: user.phone,
        role: user.role,
        name: user.name,
      },
      env.jwt.secret,
      { expiresIn: env.jwt.accessExpiresIn as any }
    );
  }

  private generateRefreshToken(user: any): string {
    return jwt.sign(
      {
        userId: user.id,
        type: 'refresh',
      },
      env.jwt.secret,
      { expiresIn: env.jwt.refreshExpiresIn as any }
    );
  }
}

export const authService = new AuthService();
