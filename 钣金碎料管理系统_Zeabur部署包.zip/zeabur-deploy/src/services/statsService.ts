// src/services/statsService.ts - 数据统计服务

import { query } from '../config/database';

export class StatsService {
  async getDashboard() {
    // 总库存
    const totalWeightResult = await query(
      `SELECT COALESCE(SUM(current_weight), 0) AS total_weight,
              COUNT(*) AS total_locations,
              COUNT(*) FILTER (WHERE status != 'empty') AS occupied_locations
       FROM storage_locations`
    );

    // 今日出入库
    const todayOpsResult = await query(
      `SELECT 
        COALESCE(SUM(weight) FILTER (WHERE operation_type = 'inbound'), 0) AS today_inbound,
        COALESCE(SUM(weight) FILTER (WHERE operation_type = 'outbound'), 0) AS today_outbound,
        COUNT(*) FILTER (WHERE operation_type = 'inbound') AS inbound_count,
        COUNT(*) FILTER (WHERE operation_type = 'outbound') AS outbound_count
       FROM operation_logs
       WHERE created_at >= CURRENT_DATE`
    );

    // 各仓库状态
    const warehouseStatsResult = await query(
      `SELECT 
        w.id, w.code, w.name, w.total_slots,
        mt.name AS material_name, mt.color AS material_color,
        COUNT(sl.id) AS actual_slots,
        COUNT(sl.id) FILTER (WHERE sl.status = 'empty') AS empty_count,
        COUNT(sl.id) FILTER (WHERE sl.status = 'partial') AS partial_count,
        COUNT(sl.id) FILTER (WHERE sl.status = 'full') AS full_count,
        COALESCE(SUM(sl.current_weight), 0) AS total_weight,
        COALESCE(SUM(sl.max_capacity), 0) AS total_capacity,
        ROUND(
          COUNT(sl.id) FILTER (WHERE sl.status != 'empty')::NUMERIC / NULLIF(COUNT(sl.id), 0) * 100, 1
        ) AS utilization_rate
       FROM warehouses w
       JOIN material_types mt ON mt.id = w.material_type_id
       LEFT JOIN storage_locations sl ON sl.warehouse_id = w.id
       WHERE w.is_active = TRUE
       GROUP BY w.id, w.code, w.name, w.total_slots, mt.name, mt.color
       ORDER BY mt.sort_order`
    );

    // 预警信息
    const alerts = this.generateAlerts(warehouseStatsResult.rows);

    return {
      total_weight: parseFloat(totalWeightResult.rows[0].total_weight),
      total_locations: parseInt(totalWeightResult.rows[0].total_locations, 10),
      occupied_locations: parseInt(totalWeightResult.rows[0].occupied_locations, 10),
      utilization_rate: totalWeightResult.rows[0].total_locations > 0
        ? Math.round(parseInt(totalWeightResult.rows[0].occupied_locations, 10) / parseInt(totalWeightResult.rows[0].total_locations, 10) * 100)
        : 0,
      today: todayOpsResult.rows[0],
      warehouses: warehouseStatsResult.rows,
      alerts,
    };
  }

  async getTrends(params: { period: string; days: number; warehouseId?: string; materialTypeId?: string }) {
    let dateTrunc: string;
    switch (params.period) {
      case 'week':
        dateTrunc = 'week';
        break;
      case 'month':
        dateTrunc = 'month';
        break;
      default:
        dateTrunc = 'day';
    }

    const conditions: string[] = [];
    const queryParams: any[] = [];
    let paramIndex = 1;

    // 时间范围
    conditions.push(`ol.created_at >= now() - $${paramIndex}::int * interval '1 day'`);
    queryParams.push(params.days);
    paramIndex++;

    if (params.warehouseId) {
      conditions.push(`ol.warehouse_id = $${paramIndex}`);
      queryParams.push(params.warehouseId);
      paramIndex++;
    }
    if (params.materialTypeId) {
      conditions.push(`ol.material_type_id = $${paramIndex}`);
      queryParams.push(params.materialTypeId);
      paramIndex++;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';

    const result = await query(
      `SELECT 
        DATE_TRUNC($1, ol.created_at)::DATE AS period_date,
        ol.operation_type,
        COALESCE(SUM(ol.weight), 0) AS total_weight,
        COUNT(*) AS operation_count
       FROM operation_logs ol
       ${whereClause}
       GROUP BY DATE_TRUNC($1, ol.created_at)::DATE, ol.operation_type
       ORDER BY period_date ASC, ol.operation_type ASC`,
      [dateTrunc, ...queryParams]
    );

    // 按日期聚合
    const grouped: Record<string, any> = {};
    for (const row of result.rows) {
      const dateStr = row.period_date.toISOString().split('T')[0];
      if (!grouped[dateStr]) {
        grouped[dateStr] = { date: dateStr, inbound_weight: 0, outbound_weight: 0, inbound_count: 0, outbound_count: 0 };
      }
      if (row.operation_type === 'inbound') {
        grouped[dateStr].inbound_weight = parseFloat(row.total_weight);
        grouped[dateStr].inbound_count = parseInt(row.operation_count, 10);
      } else {
        grouped[dateStr].outbound_weight = parseFloat(row.total_weight);
        grouped[dateStr].outbound_count = parseInt(row.operation_count, 10);
      }
    }

    return Object.values(grouped);
  }

  private generateAlerts(warehouseStats: any[]) {
    const alerts: Array<{ level: 'warning' | 'danger'; warehouse_code: string; warehouse_name: string; message: string }> = [];

    for (const ws of warehouseStats) {
      const utilization = parseFloat(ws.utilization_rate);
      const fullCount = parseInt(ws.full_count, 10);

      if (utilization >= 90) {
        alerts.push({
          level: 'danger',
          warehouse_code: ws.code,
          warehouse_name: ws.name,
          message: `${ws.name} 利用率已达 ${utilization}%`,
        });
      } else if (utilization >= 75) {
        alerts.push({
          level: 'warning',
          warehouse_code: ws.code,
          warehouse_name: ws.name,
          message: `${ws.name} 利用率超过 75%`,
        });
      }

      if (fullCount >= 10) {
        alerts.push({
          level: 'warning',
          warehouse_code: ws.code,
          warehouse_name: ws.name,
          message: `${ws.name} 已满库位达 ${fullCount} 个`,
        });
      }
    }

    return alerts;
  }
}

export const statsService = new StatsService();
