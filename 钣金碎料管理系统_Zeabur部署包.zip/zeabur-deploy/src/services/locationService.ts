// src/services/locationService.ts - 库位服务

import { query } from '../config/database';
import { NotFoundError } from '../utils/errors';

export class LocationService {
  async findById(id: string) {
    const result = await query(
      `SELECT 
        sl.id, sl.warehouse_id, sl.row_num, sl.col_num, sl.zone, sl.location_code,
        sl.status, sl.current_material_id, sl.current_weight, sl.max_capacity,
        sl.version, sl.updated_at, sl.created_at,
        mt.name AS material_name, mt.short_name AS material_short_name, mt.color AS material_color,
        w.code AS warehouse_code, w.name AS warehouse_name
       FROM storage_locations sl
       LEFT JOIN material_types mt ON mt.id = sl.current_material_id
       LEFT JOIN warehouses w ON w.id = sl.warehouse_id
       WHERE sl.id = $1`,
      [id]
    );

    if (result.rows.length === 0) {
      throw new NotFoundError('库位不存在');
    }

    return result.rows[0];
  }

  async updateLocationInventory(
    id: string,
    data: {
      status: string;
      currentMaterialId: string | null;
      currentWeight: number;
      version: number;
    }
  ) {
    const result = await query(
      `UPDATE storage_locations
       SET status = $1::location_status,
           current_material_id = $2,
           current_weight = $3,
           version = version + 1,
           updated_at = now()
       WHERE id = $4 AND version = $5
       RETURNING id, status, current_material_id, current_weight, version, updated_at`,
      [data.status, data.currentMaterialId, data.currentWeight, id, data.version]
    );

    if (result.rows.length === 0) {
      return null; // 乐观锁冲突
    }

    return result.rows[0];
  }
}

export const locationService = new LocationService();
