// src/services/userService.ts - 用户服务

import bcrypt from 'bcryptjs';
import { PoolClient } from 'pg';
import { query, transaction, getClient } from '../config/database';
import { UserRole, UserStatus } from '../types';
import { BadRequestError, NotFoundError, ConflictError } from '../utils/errors';

export class UserService {
  async findById(userId: string) {
    const result = await query(
      `SELECT id, phone, name, avatar_url, role, status, last_login_at, created_at
       FROM users WHERE id = $1`,
      [userId]
    );
    return result.rows[0] || null;
  }

  async changePassword(userId: string, oldPassword: string, newPassword: string) {
    const result = await query(
      'SELECT password_hash FROM users WHERE id = $1',
      [userId]
    );

    if (result.rows.length === 0) {
      throw new NotFoundError('用户不存在');
    }

    const isValid = await bcrypt.compare(oldPassword, result.rows[0].password_hash);
    if (!isValid) {
      throw new BadRequestError('旧密码不正确');
    }

    const hash = await bcrypt.hash(newPassword, 12);
    await query('UPDATE users SET password_hash = $1 WHERE id = $2', [hash, userId]);
  }

  async listUsers(filters: { role?: string; status?: string; page: number; pageSize: number }) {
    const conditions: string[] = [];
    const params: any[] = [];
    let paramIndex = 1;

    if (filters.role) {
      conditions.push(`role = $${paramIndex}::user_role`);
      params.push(filters.role);
      paramIndex++;
    }
    if (filters.status) {
      conditions.push(`status = $${paramIndex}::user_status`);
      params.push(filters.status);
      paramIndex++;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (filters.page - 1) * filters.pageSize;

    const [listResult, countResult] = await Promise.all([
      query(
        `SELECT id, phone, name, avatar_url, role, status, last_login_at, created_at, updated_at
         FROM users ${whereClause}
         ORDER BY created_at DESC
         LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`,
        [...params, filters.pageSize, offset]
      ),
      query(`SELECT COUNT(*) as total FROM users ${whereClause}`, params),
    ]);

    return {
      list: listResult.rows,
      total: parseInt(countResult.rows[0].total, 10),
    };
  }

  async createUser(data: {
    phone: string;
    password: string;
    name: string;
    role: UserRole;
    createdBy?: string;
  }) {
    // 检查手机号唯一性
    const existing = await query('SELECT id FROM users WHERE phone = $1', [data.phone]);
    if (existing.rows.length > 0) {
      throw new ConflictError('该手机号已注册');
    }

    const passwordHash = await bcrypt.hash(data.password, 12);
    const result = await query(
      `INSERT INTO users (phone, password_hash, name, role, status, created_by)
       VALUES ($1, $2, $3, $4, $5, $6)
       RETURNING id, phone, name, avatar_url, role, status, created_at`,
      [data.phone, passwordHash, data.name, data.role, UserStatus.ACTIVE, data.createdBy || null]
    );

    return result.rows[0];
  }

  async updateUser(userId: string, data: { name?: string; role?: UserRole; avatar_url?: string | null; updatedBy?: string }) {
    const sets: string[] = [];
    const params: any[] = [];
    let paramIndex = 1;

    if (data.name !== undefined) {
      sets.push(`name = $${paramIndex}`);
      params.push(data.name);
      paramIndex++;
    }
    if (data.role !== undefined) {
      sets.push(`role = $${paramIndex}::user_role`);
      params.push(data.role);
      paramIndex++;
    }
    if (data.avatar_url !== undefined) {
      sets.push(`avatar_url = $${paramIndex}`);
      params.push(data.avatar_url);
      paramIndex++;
    }

    if (sets.length === 0) {
      throw new BadRequestError('没有需要更新的字段');
    }

    sets.push(`updated_by = $${paramIndex}`);
    params.push(data.updatedBy || null);
    paramIndex++;

    params.push(userId);

    const result = await query(
      `UPDATE users SET ${sets.join(', ')} WHERE id = $${paramIndex}
       RETURNING id, phone, name, avatar_url, role, status, updated_at`,
      params
    );

    if (result.rows.length === 0) {
      throw new NotFoundError('用户不存在');
    }

    return result.rows[0];
  }

  async updateStatus(userId: string, status: UserStatus, updatedBy?: string) {
    const result = await query(
      `UPDATE users SET status = $1::user_status, updated_by = $2 WHERE id = $3
       RETURNING id, phone, name, role, status, updated_at`,
      [status, updatedBy || null, userId]
    );

    if (result.rows.length === 0) {
      throw new NotFoundError('用户不存在');
    }

    return result.rows[0];
  }
}

export const userService = new UserService();
