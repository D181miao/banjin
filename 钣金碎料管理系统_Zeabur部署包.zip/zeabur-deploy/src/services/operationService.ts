// src/services/operationService.ts - 出入库操作服务（核心业务逻辑）

import { PoolClient } from 'pg';
import { transaction, query } from '../config/database';
import { OperationType, OperationMode, LocationStatus } from '../types';
import { BadRequestError, ConflictError, NotFoundError } from '../utils/errors';
import { logger } from '../utils/logger';
import { wsManager } from '../websocket/manager';

export interface InboundParams {
  materialTypeId: string;
  locationId: string;
  weight: number;
  mode: 'append' | 'override';
  remark?: string;
  version: number;
  userId: string;
  ipAddress?: string;
  deviceInfo?: string;
}

export interface OutboundItem {
  locationId: string;
  weight: number;
  version: number;
}

export interface OutboundParams {
  items: OutboundItem[];
  remark?: string;
  userId: string;
  ipAddress?: string;
  deviceInfo?: string;
}

export class OperationService {
  /**
   * 入库操作 - 核心事务
   */
  async inbound(params: InboundParams) {
    return transaction(async (client) => {
      // 1. 读取库位当前状态（带行锁 FOR UPDATE）
      const locationResult = await client.query(
        `SELECT id, warehouse_id, status, current_material_id, current_weight, max_capacity, version
         FROM storage_locations WHERE id = $1 FOR UPDATE`,
        [params.locationId]
      );

      if (locationResult.rows.length === 0) {
        throw new NotFoundError('库位不存在');
      }

      const location = locationResult.rows[0];

      // 2. 乐观锁校验
      if (location.version !== params.version) {
        throw new ConflictError('该库位已被其他用户修改，请刷新后重试');
      }

      // 3. 计算新重量
      let newWeight: number;
      let opMode: OperationMode;

      if (location.status === LocationStatus.EMPTY) {
        // 空库入库
        newWeight = params.weight;
        opMode = OperationMode.EMPTY_IN;
      } else if (params.mode === 'append') {
        // 追加入库：校验物料类型一致性
        if (location.current_material_id !== params.materialTypeId) {
          throw new BadRequestError(
            '追加模式要求库位当前物料类型与入库物料类型一致'
          );
        }
        newWeight = parseFloat((parseFloat(location.current_weight) + params.weight).toFixed(1));
        opMode = OperationMode.APPEND;
      } else {
        // 覆盖入库
        newWeight = params.weight;
        opMode = OperationMode.OVERWRITE;
      }

      // 4. 校验容量
      if (newWeight > parseFloat(location.max_capacity)) {
        throw new BadRequestError(
          `入库后重量(${newWeight}kg)超过库位最大容量(${location.max_capacity}kg)`
        );
      }
      if (newWeight <= 0) {
        throw new BadRequestError('入库重量无效');
      }

      // 5. 确定新状态
      let newStatus: LocationStatus;
      if (newWeight >= parseFloat(location.max_capacity)) {
        newStatus = LocationStatus.FULL;
      } else if (newWeight > 0) {
        newStatus = LocationStatus.PARTIAL;
      } else {
        newStatus = LocationStatus.EMPTY;
      }

      const weightBefore = parseFloat(location.current_weight);

      // 6. 更新库位
      await client.query(
        `UPDATE storage_locations
         SET status = $1, current_material_id = $2, current_weight = $3,
             version = version + 1, updated_at = now()
         WHERE id = $4`,
        [newStatus, params.materialTypeId, newWeight, params.locationId]
      );

      // 7. 写入操作日志
      const logResult = await client.query(
        `INSERT INTO operation_logs 
         (user_id, operation_type, warehouse_id, location_id, material_type_id,
          weight, mode, location_weight_before, location_weight_after, remark, ip_address, device_info)
         VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
         RETURNING id, created_at`,
        [
          params.userId,
          OperationType.INBOUND,
          location.warehouse_id,
          params.locationId,
          params.materialTypeId,
          params.weight,
          opMode,
          weightBefore,
          newWeight,
          params.remark || null,
          params.ipAddress || null,
          params.deviceInfo || null,
        ]
      );

      // 8. 写入同步版本
      await client.query(
        `INSERT INTO sync_versions (table_name, record_id, operation, changed_fields)
         VALUES ('storage_locations', $1, 'update', $2)`,
        [params.locationId, ['status', 'current_material_id', 'current_weight', 'version']]
      );

      // 9. WebSocket 广播
      const syncData = {
        type: 'location_update',
        locationId: params.locationId,
        data: {
          status: newStatus,
          current_material_id: params.materialTypeId,
          current_weight: newWeight,
        },
      };
      wsManager.broadcastToAll(JSON.stringify(syncData));

      return {
        logId: logResult.rows[0].id,
        createdAt: logResult.rows[0].created_at,
        weightBefore,
        weightAfter: newWeight,
        status: newStatus,
        mode: opMode,
      };
    });
  }

  /**
   * 出库操作 - 支持多库位批量出库
   */
  async outbound(params: OutboundParams) {
    return transaction(async (client) => {
      const results: any[] = [];

      for (const item of params.items) {
        // 1. 读取库位
        const locationResult = await client.query(
          `SELECT id, warehouse_id, status, current_material_id, current_weight, max_capacity, version
           FROM storage_locations WHERE id = $1 FOR UPDATE`,
          [item.locationId]
        );

        if (locationResult.rows.length === 0) {
          throw new NotFoundError(`库位 ${item.locationId} 不存在`);
        }

        const location = locationResult.rows[0];

        // 2. 校验库位状态
        if (location.status === LocationStatus.EMPTY) {
          throw new BadRequestError(`库位 ${location.id} 为空，无法出库`);
        }

        // 3. 乐观锁校验
        if (location.version !== item.version) {
          throw new ConflictError(`库位已被其他用户修改，请刷新后重试`);
        }

        // 4. 校验出库量
        const currentWeight = parseFloat(location.current_weight);
        if (item.weight > currentWeight) {
          throw new BadRequestError(
            `出库量(${item.weight}kg)超过当前库存(${currentWeight}kg)`
          );
        }
        if (item.weight <= 0) {
          throw new BadRequestError('出库重量无效');
        }

        // 5. 计算新重量和状态
        const newWeight = parseFloat((currentWeight - item.weight).toFixed(1));
        let newStatus: LocationStatus;
        let opMode: OperationMode;

        if (newWeight <= 0) {
          newStatus = LocationStatus.EMPTY;
          opMode = OperationMode.FULL_OUT;
        } else {
          newStatus = LocationStatus.PARTIAL;
          opMode = OperationMode.PARTIAL_OUT;
        }

        const newMaterialId = newStatus === LocationStatus.EMPTY ? null : location.current_material_id;

        // 6. 更新库位
        await client.query(
          `UPDATE storage_locations
           SET status = $1, current_material_id = $2, current_weight = $3,
               version = version + 1, updated_at = now()
           WHERE id = $4`,
          [newStatus, newMaterialId, newWeight, item.locationId]
        );

        // 7. 写入操作日志
        const logResult = await client.query(
          `INSERT INTO operation_logs
           (user_id, operation_type, warehouse_id, location_id, material_type_id,
            weight, mode, location_weight_before, location_weight_after, remark, ip_address, device_info)
           VALUES ($1, $2, $3, $4, $5, $6, $7, $8, $9, $10, $11, $12)
           RETURNING id, created_at`,
          [
            params.userId,
            OperationType.OUTBOUND,
            location.warehouse_id,
            item.locationId,
            location.current_material_id,
            item.weight,
            opMode,
            currentWeight,
            newWeight,
            params.remark || null,
            params.ipAddress || null,
            params.deviceInfo || null,
          ]
        );

        // 8. 写入同步版本
        await client.query(
          `INSERT INTO sync_versions (table_name, record_id, operation, changed_fields)
           VALUES ('storage_locations', $1, 'update', $2)`,
          [item.locationId, ['status', 'current_material_id', 'current_weight', 'version']]
        );

        // 9. WebSocket 广播
        wsManager.broadcastToAll(JSON.stringify({
          type: 'location_update',
          locationId: item.locationId,
          data: {
            status: newStatus,
            current_material_id: newMaterialId,
            current_weight: newWeight,
          },
        }));

        results.push({
          logId: logResult.rows[0].id,
          locationId: item.locationId,
          weightBefore: currentWeight,
          weightAfter: newWeight,
          status: newStatus,
          mode: opMode,
        });
      }

      return { items: results };
    });
  }

  /**
   * 操作记录列表
   */
  async getOperationLogs(filters: {
    page: number;
    pageSize: number;
    operationType?: string;
    warehouseId?: string;
    materialTypeId?: string;
    userId?: string;
    startDate?: string;
    endDate?: string;
  }) {
    const conditions: string[] = [];
    const params: any[] = [];
    let paramIndex = 1;

    if (filters.operationType) {
      conditions.push(`ol.operation_type = $${paramIndex}::operation_type`);
      params.push(filters.operationType);
      paramIndex++;
    }
    if (filters.warehouseId) {
      conditions.push(`ol.warehouse_id = $${paramIndex}`);
      params.push(filters.warehouseId);
      paramIndex++;
    }
    if (filters.materialTypeId) {
      conditions.push(`ol.material_type_id = $${paramIndex}`);
      params.push(filters.materialTypeId);
      paramIndex++;
    }
    if (filters.userId) {
      conditions.push(`ol.user_id = $${paramIndex}`);
      params.push(filters.userId);
      paramIndex++;
    }
    if (filters.startDate) {
      conditions.push(`ol.created_at >= $${paramIndex}`);
      params.push(filters.startDate);
      paramIndex++;
    }
    if (filters.endDate) {
      conditions.push(`ol.created_at <= $${paramIndex}`);
      params.push(filters.endDate);
      paramIndex++;
    }

    const whereClause = conditions.length > 0 ? `WHERE ${conditions.join(' AND ')}` : '';
    const offset = (filters.page - 1) * filters.pageSize;

    const [listResult, countResult] = await Promise.all([
      query(
        `SELECT 
          ol.id, ol.operation_type, ol.weight, ol.mode,
          ol.location_weight_before, ol.location_weight_after,
          ol.remark, ol.created_at,
          sl.location_code,
          w.code AS warehouse_code, w.name AS warehouse_name,
          mt.name AS material_name, mt.color AS material_color,
          u.name AS operator_name
         FROM operation_logs ol
         JOIN storage_locations sl ON sl.id = ol.location_id
         JOIN warehouses w ON w.id = ol.warehouse_id
         JOIN material_types mt ON mt.id = ol.material_type_id
         JOIN users u ON u.id = ol.user_id
         ${whereClause}
         ORDER BY ol.created_at DESC
         LIMIT $${paramIndex} OFFSET $${paramIndex + 1}`,
        [...params, filters.pageSize, offset]
      ),
      query(
        `SELECT COUNT(*) as total FROM operation_logs ol ${whereClause}`,
        params
      ),
    ]);

    return {
      list: listResult.rows,
      total: parseInt(countResult.rows[0].total, 10),
    };
  }

  /**
   * 操作记录详情
   */
  async getOperationLogById(logId: string) {
    const result = await query(
      `SELECT 
        ol.id, ol.operation_type, ol.weight, ol.mode,
        ol.location_weight_before, ol.location_weight_after,
        ol.material_before, ol.remark, ol.device_info, ol.ip_address, ol.created_at,
        sl.location_code, sl.row_num, sl.col_num, sl.zone,
        w.code AS warehouse_code, w.name AS warehouse_name,
        mt.name AS material_name, mt.color AS material_color, mt.code AS material_code,
        u.id AS user_id, u.name AS operator_name, u.phone AS operator_phone
       FROM operation_logs ol
       JOIN storage_locations sl ON sl.id = ol.location_id
       JOIN warehouses w ON w.id = ol.warehouse_id
       JOIN material_types mt ON mt.id = ol.material_type_id
       JOIN users u ON u.id = ol.user_id
       WHERE ol.id = $1`,
      [logId]
    );

    if (result.rows.length === 0) {
      throw new NotFoundError('操作记录不存在');
    }

    return result.rows[0];
  }
}

export const operationService = new OperationService();
