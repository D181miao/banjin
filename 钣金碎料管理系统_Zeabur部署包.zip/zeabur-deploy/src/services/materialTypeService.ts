// src/services/materialTypeService.ts - 物料类型服务

import { query } from '../config/database';
import { NotFoundError, ConflictError } from '../utils/errors';

export class MaterialTypeService {
  async findAll(activeOnly = false) {
    const whereClause = activeOnly ? 'WHERE is_active = TRUE' : '';
    const result = await query(
      `SELECT id, code, name, short_name, description, color, unit, sort_order, is_active, created_at, updated_at
       FROM material_types ${whereClause}
       ORDER BY sort_order ASC, code ASC`
    );
    return result.rows;
  }

  async findById(id: string) {
    const result = await query(
      `SELECT id, code, name, short_name, description, color, unit, sort_order, is_active, created_at, updated_at
       FROM material_types WHERE id = $1`,
      [id]
    );
    return result.rows[0] || null;
  }

  async create(data: {
    code: string;
    name: string;
    short_name?: string;
    description?: string;
    color: string;
    unit?: string;
    sort_order?: number;
    createdBy?: string;
  }) {
    // 检查编码唯一性
    const existing = await query('SELECT id FROM material_types WHERE code = $1', [data.code]);
    if (existing.rows.length > 0) {
      throw new ConflictError(`物料编码 ${data.code} 已存在`);
    }

    const result = await query(
      `INSERT INTO material_types (code, name, short_name, description, color, unit, sort_order, created_by)
       VALUES ($1, $2, $3, $4, $5, $6, $7, $8)
       RETURNING id, code, name, short_name, description, color, unit, sort_order, is_active, created_at`,
      [data.code, data.name, data.short_name || null, data.description || null, data.color, data.unit || 'kg', data.sort_order || 0, data.createdBy || null]
    );

    return result.rows[0];
  }

  async update(id: string, data: {
    name?: string;
    short_name?: string | null;
    description?: string | null;
    color?: string;
    unit?: string;
    sort_order?: number;
    is_active?: boolean;
    updatedBy?: string;
  }) {
    const sets: string[] = [];
    const params: any[] = [];
    let paramIndex = 1;

    const fields = ['name', 'short_name', 'description', 'color', 'unit', 'sort_order', 'is_active'];
    for (const field of fields) {
      if ((data as any)[field] !== undefined) {
        sets.push(`${field} = $${paramIndex}`);
        params.push((data as any)[field]);
        paramIndex++;
      }
    }

    if (sets.length === 0) {
      return this.findById(id);
    }

    sets.push(`updated_by = $${paramIndex}`);
    params.push(data.updatedBy || null);
    paramIndex++;

    params.push(id);

    const result = await query(
      `UPDATE material_types SET ${sets.join(', ')} WHERE id = $${paramIndex}
       RETURNING id, code, name, short_name, description, color, unit, sort_order, is_active, updated_at`,
      params
    );

    if (result.rows.length === 0) {
      throw new NotFoundError('物料类型不存在');
    }

    return result.rows[0];
  }
}

export const materialTypeService = new MaterialTypeService();
