// src/config/env.ts - 环境变量配置

import dotenv from 'dotenv';
import path from 'path';

dotenv.config({ path: path.resolve(__dirname, '../../.env') });

// 解析 DATABASE_URL（兼容 Neon.tech / Supabase 等云平台）
function parseDbConfig() {
  const url = process.env.DATABASE_URL;
  if (url) {
    try {
      const parsed = new URL(url);
      return {
        host: parsed.hostname,
        port: parseInt(parsed.port || '5432', 10),
        database: parsed.pathname.slice(1),
        user: parsed.username,
        password: parsed.password,
        ssl: process.env.NODE_ENV === 'production', // 生产环境强制 SSL
      };
    } catch {
      // URL 解析失败，回退到独立变量
    }
  }
  return {
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT || '5432', 10),
    database: process.env.DB_NAME || 'sheet_metal_scrap',
    user: process.env.DB_USER || 'postgres',
    password: process.env.DB_PASSWORD || '',
    ssl: process.env.DB_SSL === 'true',
  };
}

const dbConfig = parseDbConfig();

export const env = {
  port: parseInt(process.env.PORT || '3000', 10),
  nodeEnv: process.env.NODE_ENV || 'development',
  db: dbConfig,
  jwt: {
    secret: process.env.JWT_SECRET || 'dev_secret_key_change_in_production',
    accessExpiresIn: process.env.JWT_ACCESS_EXPIRES_IN || '1d',
    refreshExpiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d',
  },
  ws: {
    path: process.env.WS_PATH || '/ws',
  },
  logLevel: process.env.LOG_LEVEL || 'info',
  corsOrigin: process.env.CORS_ORIGIN || '*',
};
