// src/utils/response.ts - 统一响应格式

import { Response } from 'express';

export function success(res: Response, data: any = null, message = 'success', statusCode = 200) {
  return res.status(statusCode).json({
    code: 0,
    message,
    data,
  });
}

export function fail(res: Response, message: string, statusCode = 400, code = 'ERROR') {
  return res.status(statusCode).json({
    code,
    message,
    data: null,
  });
}

export function paginated<T>(
  res: Response,
  list: T[],
  total: number,
  page: number,
  pageSize: number
) {
  return res.status(200).json({
    code: 0,
    message: 'success',
    data: {
      list,
      total,
      page,
      page_size: pageSize,
    },
  });
}
