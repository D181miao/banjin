// src/utils/logger.ts - 日志工具

import { env } from '../config/env';

type LogLevel = 'error' | 'warn' | 'info' | 'debug';

const levels: Record<LogLevel, number> = { error: 0, warn: 1, info: 2, debug: 3 };
const currentLevel = levels[env.logLevel as LogLevel] ?? 2;

function formatMessage(level: string, message: string, meta?: any): string {
  const timestamp = new Date().toISOString();
  const metaStr = meta ? ` ${JSON.stringify(meta)}` : '';
  return `[${timestamp}] [${level.toUpperCase()}] ${message}${metaStr}`;
}

export const logger = {
  error(message: string, meta?: any) {
    if (currentLevel >= levels.error) console.error(formatMessage('error', message, meta));
  },
  warn(message: string, meta?: any) {
    if (currentLevel >= levels.warn) console.warn(formatMessage('warn', message, meta));
  },
  info(message: string, meta?: any) {
    if (currentLevel >= levels.info) console.log(formatMessage('info', message, meta));
  },
  debug(message: string, meta?: any) {
    if (currentLevel >= levels.debug) console.log(formatMessage('debug', message, meta));
  },
};
