// src/middleware/errorHandler.ts - 全局错误处理中间件

import { Request, Response, NextFunction } from 'express';
import { AppError } from '../utils/errors';
import { logger } from '../utils/logger';

export function errorHandler(err: Error, _req: Request, res: Response, _next: NextFunction) {
  // 业务错误
  if (err instanceof AppError) {
    return res.status(err.statusCode).json({
      code: err.code,
      message: err.message,
      data: null,
    });
  }

  // Zod 校验错误（漏网之鱼）
  if (err.name === 'ZodError') {
    return res.status(400).json({
      code: 'VALIDATION_ERROR',
      message: '参数校验失败',
      data: null,
    });
  }

  // PostgreSQL 唯一约束冲突
  if ((err as any).code === '23505') {
    return res.status(409).json({
      code: 'DUPLICATE_ENTRY',
      message: '数据已存在（唯一约束冲突）',
      data: null,
    });
  }

  // 未知错误
  logger.error('Unhandled error', { error: err.message, stack: err.stack });
  return res.status(500).json({
    code: 'INTERNAL_ERROR',
    message: '服务内部错误',
    data: null,
  });
}

export function notFoundHandler(_req: Request, res: Response) {
  return res.status(404).json({
    code: 'NOT_FOUND',
    message: '接口不存在',
    data: null,
  });
}
