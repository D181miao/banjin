// src/middleware/auth.ts - JWT 认证中间件

import { Response, NextFunction } from 'express';
import jwt from 'jsonwebtoken';
import { env } from '../config/env';
import { AuthRequest, JWTPayload } from '../types';
import { UnauthorizedError } from '../utils/errors';

export function authenticate(req: AuthRequest, _res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      throw new UnauthorizedError('未提供认证令牌');
    }

    const token = authHeader.substring(7);
    const decoded = jwt.verify(token, env.jwt.secret) as JWTPayload;

    req.user = decoded;
    next();
  } catch (error) {
    if (error instanceof jwt.JsonWebTokenError) {
      next(new UnauthorizedError('认证令牌无效或已过期'));
    } else if (error instanceof jwt.TokenExpiredError) {
      next(new UnauthorizedError('认证令牌已过期，请重新登录'));
    } else {
      next(error);
    }
  }
}

export function optionalAuth(req: AuthRequest, _res: Response, next: NextFunction) {
  try {
    const authHeader = req.headers.authorization;
    if (authHeader && authHeader.startsWith('Bearer ')) {
      const token = authHeader.substring(7);
      const decoded = jwt.verify(token, env.jwt.secret) as JWTPayload;
      req.user = decoded;
    }
  } catch {
    // Ignore auth errors for optional auth
  }
  next();
}
