// src/middleware/roleCheck.ts - 角色权限中间件

import { Response, NextFunction } from 'express';
import { AuthRequest, UserRole } from '../types';
import { ForbiddenError } from '../utils/errors';

// 角色层级: viewer < operator < admin < super_admin
const roleHierarchy: Record<UserRole, number> = {
  [UserRole.VIEWER]: 0,
  [UserRole.OPERATOR]: 1,
  [UserRole.ADMIN]: 2,
  [UserRole.SUPER_ADMIN]: 3,
};

export function requireRole(...roles: UserRole[]) {
  return (req: AuthRequest, _res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new ForbiddenError('未获取到用户信息'));
    }

    if (!roles.includes(req.user.role)) {
      return next(new ForbiddenError(`需要以下角色之一: ${roles.join(', ')}`));
    }

    next();
  };
}

export function requireMinRole(minRole: UserRole) {
  return (req: AuthRequest, _res: Response, next: NextFunction) => {
    if (!req.user) {
      return next(new ForbiddenError('未获取到用户信息'));
    }

    const userLevel = roleHierarchy[req.user.role] || 0;
    const requiredLevel = roleHierarchy[minRole] || 0;

    if (userLevel < requiredLevel) {
      return next(new ForbiddenError(`需要至少 ${minRole} 角色权限`));
    }

    next();
  };
}

// 便捷角色检查
export const requireOperator = requireMinRole(UserRole.OPERATOR);
export const requireAdmin = requireMinRole(UserRole.ADMIN);
export const requireSuperAdmin = requireMinRole(UserRole.SUPER_ADMIN);
