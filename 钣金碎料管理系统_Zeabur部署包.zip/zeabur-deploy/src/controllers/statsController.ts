// src/controllers/statsController.ts - 数据统计控制器

import { Response, NextFunction } from 'express';
import { statsService } from '../services/statsService';
import { AuthRequest } from '../types';
import { success } from '../utils/response';

export class StatsController {
  async getDashboard(_req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const data = await statsService.getDashboard();
      success(res, data);
    } catch (error) {
      next(error);
    }
  }

  async getTrends(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { period = 'day', days = '30', warehouse_id, material_type_id } = req.query;
      const data = await statsService.getTrends({
        period: period as string,
        days: parseInt(days as string, 10),
        warehouseId: warehouse_id as string,
        materialTypeId: material_type_id as string,
      });
      success(res, data);
    } catch (error) {
      next(error);
    }
  }
}

export const statsController = new StatsController();
