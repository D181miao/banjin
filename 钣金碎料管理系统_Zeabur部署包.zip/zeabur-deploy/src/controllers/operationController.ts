// src/controllers/operationController.ts - 出入库操作控制器

import { Response, NextFunction } from 'express';
import { operationService } from '../services/operationService';
import { AuthRequest } from '../types';
import { success, paginated } from '../utils/response';

export class OperationController {
  async inbound(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { material_type_id, location_id, weight, mode, remark, version } = req.body;
      const ip = req.ip || req.headers['x-forwarded-for'] as string;
      const deviceInfo = req.headers['user-agent']?.substring(0, 200);

      const result = await operationService.inbound({
        materialTypeId: material_type_id,
        locationId: location_id,
        weight,
        mode,
        remark,
        version,
        userId: req.user!.userId,
        ipAddress: ip,
        deviceInfo,
      });

      success(res, result, '入库操作成功');
    } catch (error) {
      next(error);
    }
  }

  async outbound(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { items, remark } = req.body;
      const ip = req.ip || req.headers['x-forwarded-for'] as string;
      const deviceInfo = req.headers['user-agent']?.substring(0, 200);

      const outboundItems = items.map((item: any) => ({
        locationId: item.location_id,
        weight: item.weight,
        version: item.version,
      }));

      const result = await operationService.outbound({
        items: outboundItems,
        remark,
        userId: req.user!.userId,
        ipAddress: ip,
        deviceInfo,
      });

      success(res, result, '出库操作成功');
    } catch (error) {
      next(error);
    }
  }

  async getLogs(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const {
        page = '1',
        page_size = '20',
        operation_type,
        warehouse_id,
        material_type_id,
        user_id,
        start_date,
        end_date,
      } = req.query;

      const result = await operationService.getOperationLogs({
        page: parseInt(page as string, 10),
        pageSize: parseInt(page_size as string, 10),
        operationType: operation_type as string,
        warehouseId: warehouse_id as string,
        materialTypeId: material_type_id as string,
        userId: user_id as string,
        startDate: start_date as string,
        endDate: end_date as string,
      });

      paginated(
        res,
        result.list,
        result.total,
        parseInt(page as string, 10),
        parseInt(page_size as string, 10)
      );
    } catch (error) {
      next(error);
    }
  }

  async getLogById(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const log = await operationService.getOperationLogById(id);
      success(res, log);
    } catch (error) {
      next(error);
    }
  }
}

export const operationController = new OperationController();
