// src/controllers/userController.ts - 用户控制器

import { Response, NextFunction } from 'express';
import { userService } from '../services/userService';
import { AuthRequest } from '../types';
import { success, paginated } from '../utils/response';

export class UserController {
  async getMe(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const user = await userService.findById(req.user!.userId);
      success(res, user);
    } catch (error) {
      next(error);
    }
  }

  async changePassword(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { oldPassword, newPassword } = req.body;
      await userService.changePassword(req.user!.userId, oldPassword, newPassword);
      success(res, null, '密码修改成功');
    } catch (error) {
      next(error);
    }
  }

  async listUsers(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { role, status, page = '1', page_size = '20' } = req.query;
      const result = await userService.listUsers({
        role: role as string,
        status: status as string,
        page: parseInt(page as string, 10),
        pageSize: parseInt(page_size as string, 10),
      });
      paginated(res, result.list, result.total, parseInt(page as string, 10), parseInt(page_size as string, 10));
    } catch (error) {
      next(error);
    }
  }

  async createUser(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const user = await userService.createUser({
        ...req.body,
        createdBy: req.user!.userId,
      });
      success(res, user, '用户创建成功', 201);
    } catch (error) {
      next(error);
    }
  }

  async updateUser(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const user = await userService.updateUser(id, {
        ...req.body,
        updatedBy: req.user!.userId,
      });
      success(res, user, '用户更新成功');
    } catch (error) {
      next(error);
    }
  }

  async updateStatus(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const { status } = req.body;
      const user = await userService.updateStatus(id, status, req.user!.userId);
      success(res, user, `用户已${status === 'active' ? '启用' : '禁用'}`);
    } catch (error) {
      next(error);
    }
  }
}

export const userController = new UserController();
