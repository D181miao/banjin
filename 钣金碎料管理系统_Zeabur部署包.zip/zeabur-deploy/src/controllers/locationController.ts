// src/controllers/locationController.ts - 库位控制器

import { Response, NextFunction } from 'express';
import { locationService } from '../services/locationService';
import { AuthRequest } from '../types';
import { success } from '../utils/response';

export class LocationController {
  async findById(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const location = await locationService.findById(id);
      success(res, location);
    } catch (error) {
      next(error);
    }
  }
}

export const locationController = new LocationController();
