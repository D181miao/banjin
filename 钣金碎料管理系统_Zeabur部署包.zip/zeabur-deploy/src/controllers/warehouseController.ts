// src/controllers/warehouseController.ts - 仓库控制器

import { Response, NextFunction } from 'express';
import { warehouseService } from '../services/warehouseService';
import { AuthRequest } from '../types';
import { success } from '../utils/response';

export class WarehouseController {
  async findAll(_req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const list = await warehouseService.findAll();
      success(res, list);
    } catch (error) {
      next(error);
    }
  }

  async findById(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const warehouse = await warehouseService.findById(id);
      success(res, warehouse);
    } catch (error) {
      next(error);
    }
  }

  async getLocations(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const result = await warehouseService.getLocations(id);
      success(res, result);
    } catch (error) {
      next(error);
    }
  }
}

export const warehouseController = new WarehouseController();
