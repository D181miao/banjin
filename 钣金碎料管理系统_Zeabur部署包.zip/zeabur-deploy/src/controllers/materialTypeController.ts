// src/controllers/materialTypeController.ts - 物料类型控制器

import { Response, NextFunction } from 'express';
import { materialTypeService } from '../services/materialTypeService';
import { AuthRequest } from '../types';
import { success } from '../utils/response';

export class MaterialTypeController {
  async findAll(_req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const list = await materialTypeService.findAll();
      success(res, list);
    } catch (error) {
      next(error);
    }
  }

  async create(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const result = await materialTypeService.create({
        ...req.body,
        createdBy: req.user!.userId,
      });
      success(res, result, '物料类型创建成功', 201);
    } catch (error) {
      next(error);
    }
  }

  async update(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { id } = req.params;
      const result = await materialTypeService.update(id, {
        ...req.body,
        updatedBy: req.user!.userId,
      });
      success(res, result, '物料类型更新成功');
    } catch (error) {
      next(error);
    }
  }
}

export const materialTypeController = new MaterialTypeController();
