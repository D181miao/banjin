// src/controllers/authController.ts - 认证控制器

import { Response, NextFunction } from 'express';
import { authService } from '../services/authService';
import { AuthRequest } from '../types';
import { success } from '../utils/response';

export class AuthController {
  async login(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { phone, password } = req.body;
      const ip = req.ip || req.headers['x-forwarded-for'] as string;
      const result = await authService.login(phone, password, ip);
      success(res, result, '登录成功');
    } catch (error) {
      next(error);
    }
  }

  async refresh(req: AuthRequest, res: Response, next: NextFunction) {
    try {
      const { refreshToken } = req.body;
      const result = await authService.refresh(refreshToken);
      success(res, result, '令牌刷新成功');
    } catch (error) {
      next(error);
    }
  }
}

export const authController = new AuthController();
