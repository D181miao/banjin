// src/types/index.ts - 全局类型定义

// ============================================================
// 枚举类型
// ============================================================

export enum UserRole {
  VIEWER = 'viewer',
  OPERATOR = 'operator',
  ADMIN = 'admin',
  SUPER_ADMIN = 'super_admin',
}

export enum UserStatus {
  ACTIVE = 'active',
  DISABLED = 'disabled',
}

export enum LocationStatus {
  EMPTY = 'empty',
  PARTIAL = 'partial',
  FULL = 'full',
}

export enum WarehouseLayoutType {
  STANDARD = 'standard',
  SPLIT_ZONE = 'split_zone',
}

export enum OperationType {
  INBOUND = 'inbound',
  OUTBOUND = 'outbound',
}

export enum OperationMode {
  APPEND = 'append',
  OVERWRITE = 'overwrite',
  EMPTY_IN = 'empty_in',
  PARTIAL_OUT = 'partial_out',
  FULL_OUT = 'full_out',
}

export enum SyncOperation {
  INSERT = 'insert',
  UPDATE = 'update',
  DELETE = 'delete',
}

// ============================================================
// 数据模型
// ============================================================

export interface User {
  id: string;
  phone: string;
  password_hash: string;
  name: string;
  avatar_url: string | null;
  role: UserRole;
  status: UserStatus;
  last_login_at: Date | null;
  last_login_ip: string | null;
  created_at: Date;
  updated_at: Date;
  created_by: string | null;
  updated_by: string | null;
}

export interface MaterialType {
  id: string;
  code: string;
  name: string;
  short_name: string | null;
  description: string | null;
  color: string;
  unit: string;
  sort_order: number;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
  created_by: string | null;
  updated_by: string | null;
}

export interface Warehouse {
  id: string;
  material_type_id: string;
  code: string;
  name: string;
  rows: number;
  cols: number;
  total_slots: number;
  layout_type: WarehouseLayoutType;
  layout_config: any;
  default_max_capacity: number;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
  created_by: string | null;
  updated_by: string | null;
}

export interface StorageLocation {
  id: string;
  warehouse_id: string;
  row_num: number;
  col_num: number;
  zone: string;
  location_code: string;
  status: LocationStatus;
  current_material_id: string | null;
  current_weight: number;
  max_capacity: number;
  version: number;
  updated_at: Date;
  created_at: Date;
}

export interface OperationLog {
  id: string;
  user_id: string;
  operation_type: OperationType;
  warehouse_id: string;
  location_id: string;
  material_type_id: string;
  weight: number;
  mode: OperationMode;
  location_weight_before: number;
  location_weight_after: number;
  material_before: string | null;
  remark: string | null;
  device_info: string | null;
  ip_address: string | null;
  created_at: Date;
}

export interface SystemConfig {
  id: string;
  config_key: string;
  config_value: any;
  config_type: string;
  description: string | null;
  is_public: boolean;
  created_at: Date;
  updated_at: Date;
  created_by: string | null;
  updated_by: string | null;
}

export interface SyncVersion {
  id: string;
  table_name: string;
  record_id: string;
  version: string;
  operation: SyncOperation;
  changed_fields: string[] | null;
  created_at: Date;
}

// ============================================================
// JWT Payload
// ============================================================

export interface JWTPayload {
  userId: string;
  phone: string;
  role: UserRole;
  name: string;
}

// ============================================================
// Express 扩展
// ============================================================

import { Request } from 'express';

export interface AuthRequest extends Request {
  user?: JWTPayload;
}

// ============================================================
// API 响应
// ============================================================

export interface ApiResponse<T = any> {
  code: number;
  message: string;
  data?: T;
}

export interface PaginatedResponse<T> {
  list: T[];
  total: number;
  page: number;
  page_size: number;
}
