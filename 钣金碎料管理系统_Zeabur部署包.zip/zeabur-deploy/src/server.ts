// src/server.ts - Zeabur 部署入口（标准 Node.js 服务）

import http from 'http';
import path from 'path';
import fs from 'fs';
import express from 'express';
import cors from 'cors';
import helmet from 'helmet';

import { env } from './config/env';
import { pool } from './config/database';
import routes from './routes';
import { errorHandler, notFoundHandler } from './middleware/errorHandler';
import { requestLogger } from './middleware/requestLogger';
import { wsManager } from './websocket/manager';

// ============================================================
// 创建 Express 应用
// ============================================================
const app = express();

// 基础中间件
app.use(helmet({
  contentSecurityPolicy: false,
}));
app.use(cors({ origin: env.corsOrigin, credentials: true }));
app.use(express.json({ limit: '10mb' }));
app.use(express.urlencoded({ extended: true }));

// 请求日志
app.use(requestLogger);

// API 路由
app.use('/api', routes);

// 静态文件服务 - web 目录
const webDir = path.resolve(__dirname, '../web');
app.use(express.static(webDir));

// SPA 回退：所有非 API 请求返回 index.html
app.get('*', (req, res, next) => {
  if (!req.path.startsWith('/api')) {
    const indexPath = path.join(webDir, 'index.html');
    if (fs.existsSync(indexPath)) {
      return res.sendFile(indexPath);
    }
  }
  next();
});

// 404 处理
app.use(notFoundHandler);

// 全局错误处理
app.use(errorHandler);

// ============================================================
// 数据库自动初始化
// ============================================================
async function initDatabase(): Promise<void> {
  try {
    // 检查 users 表是否已存在
    const result = await pool.query(
      "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'users')"
    );
    const dbExists = result.rows[0].exists;

    if (dbExists) {
      console.log('✅ 数据库表结构已存在，跳过初始化');
      return;
    }

    console.log('🚀 首次启动，开始初始化数据库...');

    // 查找 SQL 文件
    const sqlPaths = [
      path.resolve(__dirname, '../database/init.sql'),
      path.resolve(__dirname, '../../database/init.sql'),
    ];

    let sqlFile = '';
    for (const p of sqlPaths) {
      if (fs.existsSync(p)) {
        sqlFile = p;
        break;
      }
    }

    if (!sqlFile) {
      console.warn('⚠️ 找不到建表 SQL 文件，跳过自动初始化');
      return;
    }

    console.log(`📄 读取 SQL 文件: ${sqlFile}`);
    const sql = fs.readFileSync(sqlFile, 'utf-8');

    // 逐条执行 SQL
    const statements = sql.split(';').map(s => s.trim()).filter(s => s.length > 0);
    let executed = 0;

    for (const stmt of statements) {
      const clean = stmt.split('\n').filter(l => !l.trim().startsWith('--')).join('\n').trim();
      if (!clean) continue;

      try {
        await pool.query(clean);
        executed++;
      } catch (e: any) {
        if (e.code !== '42P07' && e.code !== '42710' && !e.message?.includes('already exists')) {
          console.warn(`SQL 执行警告: ${e.message?.substring(0, 80)}`);
        }
      }
    }
    console.log(`✅ SQL 建表完成 (${executed} 条语句)`);

    // Seed 默认用户
    const bcrypt = await import('bcryptjs');

    const users = [
      { phone: '181', name: '超级管理员', role: 'super_admin', password: '123456' },
      { phone: '110003199', name: '操作员', role: 'operator', password: '123456' },
    ];

    for (const u of users) {
      const hash = await bcrypt.default.hash(u.password, 12);
      try {
        await pool.query(
          'INSERT INTO users (phone, password_hash, name, role, status) VALUES ($1, $2, $3, $4, $5)',
          [u.phone, hash, u.name, u.role, 'active']
        );
      } catch (e: any) {
        if (e.code !== '23505') {
          console.warn(`用户创建警告: ${e.message?.substring(0, 80)}`);
        }
      }
    }
    console.log('✅ 默认用户创建完成');

    // 生成库位
    const locCount = await pool.query('SELECT COUNT(*) FROM storage_locations');
    if (parseInt(locCount.rows[0].count) === 0) {
      try {
        await pool.query('SELECT generate_storage_locations()');
        console.log('✅ 库位生成完成');
      } catch (e) {
        console.warn('库位生成函数调用失败');
      }
    }

    console.log('🎉 数据库初始化完成');
  } catch (e) {
    console.error('❌ 数据库初始化失败:', e);
  }
}

// ============================================================
// 启动服务器
// ============================================================
async function main() {
  // 1. 初始化数据库
  await initDatabase();

  // 2. 创建 HTTP 服务器
  const server = http.createServer(app);

  // 3. 初始化 WebSocket
  wsManager.init(server);

  // 4. 启动监听
  const port = env.port;
  server.listen(port, () => {
    console.log(`🚀 钣金碎料管理系统已启动`);
    console.log(`📍 地址: http://localhost:${port}`);
    console.log(`🔌 WebSocket: ws://localhost:${port}${env.ws.path}`);
    console.log(`🌍 环境: ${env.nodeEnv}`);
  });

  // 5. 优雅退出
  const shutdown = async (signal: string) => {
    console.log(`\n${signal} 收到，正在关闭...`);
    wsManager.shutdown();
    server.close(() => {
      console.log('HTTP 服务器已关闭');
      pool.end().then(() => {
        console.log('数据库连接已关闭');
        process.exit(0);
      });
    });
    // 10 秒强制退出
    setTimeout(() => process.exit(1), 10000);
  };

  process.on('SIGTERM', () => shutdown('SIGTERM'));
  process.on('SIGINT', () => shutdown('SIGINT'));
}

main().catch((err) => {
  console.error('启动失败:', err);
  process.exit(1);
});
