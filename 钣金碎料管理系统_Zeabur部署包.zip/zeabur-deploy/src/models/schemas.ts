// src/models/schemas.ts - Zod 校验 Schema 定义

import { z } from 'zod';

// ============================================================
// 认证模块
// ============================================================

export const loginSchema = z.object({
  phone: z.string().min(3, '手机号至少3位').max(20),
  password: z.string().min(6, '密码至少6位'),
});

export const refreshSchema = z.object({
  refreshToken: z.string().min(1, '刷新令牌不能为空'),
});

// ============================================================
// 用户模块
// ============================================================

export const changePasswordSchema = z.object({
  oldPassword: z.string().min(6, '旧密码至少6位'),
  newPassword: z.string().min(6, '新密码至少6位').max(50),
});

export const createUserSchema = z.object({
  phone: z.string().regex(/^1[3-9]\d{9}$/, '手机号格式不正确'),
  password: z.string().min(6, '密码至少6位').max(50),
  name: z.string().min(1, '姓名不能为空').max(50),
  role: z.enum(['operator', 'admin', 'super_admin']),
});

export const updateUserSchema = z.object({
  name: z.string().min(1).max(50).optional(),
  role: z.enum(['operator', 'admin', 'super_admin']).optional(),
  avatar_url: z.string().max(500).nullable().optional(),
});

export const updateStatusSchema = z.object({
  status: z.enum(['active', 'disabled']),
});

// ============================================================
// 物料类型模块
// ============================================================

export const createMaterialTypeSchema = z.object({
  code: z.string().min(1).max(20),
  name: z.string().min(1).max(100),
  short_name: z.string().max(20).optional(),
  description: z.string().max(500).optional(),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/, '颜色格式必须为HEX，如 #E74C3C'),
  unit: z.string().max(10).default('kg'),
  sort_order: z.number().int().min(0).default(0),
});

export const updateMaterialTypeSchema = z.object({
  name: z.string().min(1).max(100).optional(),
  short_name: z.string().max(20).nullable().optional(),
  description: z.string().max(500).nullable().optional(),
  color: z.string().regex(/^#[0-9A-Fa-f]{6}$/).optional(),
  unit: z.string().max(10).optional(),
  sort_order: z.number().int().min(0).optional(),
  is_active: z.boolean().optional(),
});

// ============================================================
// 出库操作模块
// ============================================================

export const inboundSchema = z.object({
  material_type_id: z.string().uuid('物料类型ID必须为UUID格式'),
  location_id: z.string().uuid('库位ID必须为UUID格式'),
  weight: z.number().positive('重量必须大于0').max(99999.9),
  mode: z.enum(['append', 'override'], {
    errorMap: () => ({ message: '模式必须为 append 或 override' }),
  }),
  remark: z.string().max(500).optional(),
  version: z.number().int().min(0, 'version 用于乐观锁校验'),
});

export const outboundItemSchema = z.object({
  location_id: z.string().uuid('库位ID必须为UUID格式'),
  weight: z.number().positive('出库重量必须大于0').max(99999.9),
  version: z.number().int().min(0, 'version 用于乐观锁校验'),
});

export const outboundSchema = z.object({
  items: z.array(outboundItemSchema).min(1, '至少选择一个库位出库'),
  remark: z.string().max(500).optional(),
});

// ============================================================
// 操作记录查询
// ============================================================

export const operationLogsQuerySchema = z.object({
  page: z.coerce.number().int().min(1).default(1),
  page_size: z.coerce.number().int().min(1).max(100).default(20),
  operation_type: z.enum(['inbound', 'outbound']).optional(),
  warehouse_id: z.string().uuid().optional(),
  material_type_id: z.string().uuid().optional(),
  user_id: z.string().uuid().optional(),
  start_date: z.string().datetime({ offset: true }).optional(),
  end_date: z.string().datetime({ offset: true }).optional(),
});

// ============================================================
// 数据统计查询
// ============================================================

export const trendsQuerySchema = z.object({
  period: z.enum(['day', 'week', 'month']).default('day'),
  days: z.coerce.number().int().min(1).max(365).default(30),
  warehouse_id: z.string().uuid().optional(),
  material_type_id: z.string().uuid().optional(),
});

// ============================================================
// UUID 路径参数
// ============================================================

export const uuidParamSchema = z.object({
  id: z.string().uuid('ID必须为UUID格式'),
});
