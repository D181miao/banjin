// src/routes/index.ts - 路由汇总

import { Router } from 'express';
import authRoutes from './auth';
import userRoutes from './users';
import materialTypeRoutes from './materialTypes';
import warehouseRoutes from './warehouses';
import locationRoutes from './locations';
import operationRoutes from './operations';
import statsRoutes from './stats';

const router = Router();

// 公开路由
router.use('/auth', authRoutes);

// 受保护的路由
router.use('/users', userRoutes);
router.use('/material-types', materialTypeRoutes);
router.use('/warehouses', warehouseRoutes);
router.use('/locations', locationRoutes);
router.use('/operations', operationRoutes);
router.use('/stats', statsRoutes);

// 健康检查
router.get('/health', (_req, res) => {
  res.json({ code: 0, message: 'OK', data: { timestamp: new Date().toISOString() } });
});

export default router;
