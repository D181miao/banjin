// src/routes/materialTypes.ts - 物料类型路由

import { Router } from 'express';
import { materialTypeController } from '../controllers/materialTypeController';
import { authenticate } from '../middleware/auth';
import { requireSuperAdmin } from '../middleware/roleCheck';
import { validateBody, validateParams } from '../middleware/validate';
import { createMaterialTypeSchema, updateMaterialTypeSchema, uuidParamSchema } from '../models/schemas';

const router = Router();

// 所有路由需要认证
router.use(authenticate);

// GET /api/material-types - 获取所有物料类型
router.get('/', materialTypeController.findAll.bind(materialTypeController));

// POST /api/material-types - 创建物料类型（超级管理员）
router.post('/', requireSuperAdmin, validateBody(createMaterialTypeSchema), materialTypeController.create.bind(materialTypeController));

// PUT /api/material-types/:id - 编辑物料类型（超级管理员）
router.put('/:id', requireSuperAdmin, validateParams(uuidParamSchema), validateBody(updateMaterialTypeSchema), materialTypeController.update.bind(materialTypeController));

export default router;
