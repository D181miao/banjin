// src/routes/auth.ts - 认证路由

import { Router } from 'express';
import { authController } from '../controllers/authController';
import { validateBody } from '../middleware/validate';
import { loginSchema, refreshSchema } from '../models/schemas';

const router = Router();

// POST /api/auth/login - 登录
router.post('/login', validateBody(loginSchema), authController.login.bind(authController));

// POST /api/auth/refresh - 刷新令牌
router.post('/refresh', validateBody(refreshSchema), authController.refresh.bind(authController));

export default router;
