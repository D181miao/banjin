// src/routes/users.ts - 用户路由

import { Router } from 'express';
import { userController } from '../controllers/userController';
import { authenticate } from '../middleware/auth';
import { requireSuperAdmin, requireAdmin } from '../middleware/roleCheck';
import { validateBody, validateParams } from '../middleware/validate';
import { changePasswordSchema, createUserSchema, updateUserSchema, updateStatusSchema, uuidParamSchema } from '../models/schemas';

const router = Router();

// 所有路由需要认证
router.use(authenticate);

// GET /api/users/me - 获取当前用户
router.get('/me', userController.getMe.bind(userController));

// PUT /api/users/me/password - 修改密码
router.put('/me/password', validateBody(changePasswordSchema), userController.changePassword.bind(userController));

// GET /api/users - 用户列表（管理员及以上）
router.get('/', requireAdmin, userController.listUsers.bind(userController));

// POST /api/users - 创建用户（超级管理员）
router.post('/', requireSuperAdmin, validateBody(createUserSchema), userController.createUser.bind(userController));

// PUT /api/users/:id - 编辑用户（超级管理员）
router.put('/:id', requireSuperAdmin, validateParams(uuidParamSchema), validateBody(updateUserSchema), userController.updateUser.bind(userController));

// PUT /api/users/:id/status - 启用/禁用用户（超级管理员）
router.put('/:id/status', requireSuperAdmin, validateParams(uuidParamSchema), validateBody(updateStatusSchema), userController.updateStatus.bind(userController));

export default router;
