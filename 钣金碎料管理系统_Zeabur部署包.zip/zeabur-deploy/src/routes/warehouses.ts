// src/routes/warehouses.ts - 仓库路由

import { Router } from 'express';
import { warehouseController } from '../controllers/warehouseController';
import { authenticate } from '../middleware/auth';
import { validateParams } from '../middleware/validate';
import { uuidParamSchema } from '../models/schemas';

const router = Router();

// 所有路由需要认证
router.use(authenticate);

// GET /api/warehouses - 获取所有仓库及布局
router.get('/', warehouseController.findAll.bind(warehouseController));

// GET /api/warehouses/:id - 获取仓库详情含库位列表
router.get('/:id', validateParams(uuidParamSchema), warehouseController.findById.bind(warehouseController));

// GET /api/warehouses/:id/locations - 获取仓库库位网格数据
router.get('/:id/locations', validateParams(uuidParamSchema), warehouseController.getLocations.bind(warehouseController));

export default router;
