// src/routes/stats.ts - 数据统计路由

import { Router } from 'express';
import { statsController } from '../controllers/statsController';
import { authenticate } from '../middleware/auth';
import { validateQuery } from '../middleware/validate';
import { trendsQuerySchema } from '../models/schemas';

const router = Router();

// 所有路由需要认证（viewer及以上均可访问数据面板）
router.use(authenticate);

// GET /api/stats/dashboard - 仪表盘数据
router.get('/dashboard', statsController.getDashboard.bind(statsController));

// GET /api/stats/trends - 趋势数据
router.get('/trends', validateQuery(trendsQuerySchema), statsController.getTrends.bind(statsController));

export default router;
