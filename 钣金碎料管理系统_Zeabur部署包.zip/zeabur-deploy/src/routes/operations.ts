// src/routes/operations.ts - 出入库操作路由

import { Router } from 'express';
import { operationController } from '../controllers/operationController';
import { authenticate } from '../middleware/auth';
import { requireOperator } from '../middleware/roleCheck';
import { validateBody, validateQuery, validateParams } from '../middleware/validate';
import { inboundSchema, outboundSchema, operationLogsQuerySchema, uuidParamSchema } from '../models/schemas';

const router = Router();

// 所有路由需要认证
router.use(authenticate);

// 只读路由 — 所有角色（含viewer）均可访问
router.get('/logs', validateQuery(operationLogsQuerySchema), operationController.getLogs.bind(operationController));
router.get('/logs/:id', validateParams(uuidParamSchema), operationController.getLogById.bind(operationController));

// 写入路由 — 需操作员及以上权限
router.use(requireOperator);

// POST /api/operations/inbound - 入库操作
router.post('/inbound', validateBody(inboundSchema), operationController.inbound.bind(operationController));

// POST /api/operations/outbound - 出库操作
router.post('/outbound', validateBody(outboundSchema), operationController.outbound.bind(operationController));

export default router;
