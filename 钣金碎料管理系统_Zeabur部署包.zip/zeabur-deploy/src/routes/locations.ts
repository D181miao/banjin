// src/routes/locations.ts - 库位路由

import { Router } from 'express';
import { locationController } from '../controllers/locationController';
import { authenticate } from '../middleware/auth';
import { validateParams } from '../middleware/validate';
import { uuidParamSchema } from '../models/schemas';

const router = Router();

// 所有路由需要认证
router.use(authenticate);

// GET /api/locations/:id - 获取库位详情含当前库存
router.get('/:id', validateParams(uuidParamSchema), locationController.findById.bind(locationController));

export default router;
