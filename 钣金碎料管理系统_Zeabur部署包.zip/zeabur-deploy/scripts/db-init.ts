// scripts/db-init.ts - 独立数据库初始化脚本
// 用法: DATABASE_URL=postgresql://... npx tsx scripts/db-init.ts

import { Pool } from 'pg';
import fs from 'fs';
import path from 'path';
import bcrypt from 'bcryptjs';

async function main() {
  const databaseUrl = process.env.DATABASE_URL;
  if (!databaseUrl) {
    console.error('❌ 请设置 DATABASE_URL 环境变量');
    console.error('示例: DATABASE_URL=postgresql://user:pass@host:5432/dbname npx tsx scripts/db-init.ts');
    process.exit(1);
  }

  console.log('🔌 连接数据库...');
  const pool = new Pool({
    connectionString: databaseUrl,
    ssl: { rejectUnauthorized: false },
  });

  try {
    // 检查连接
    await pool.query('SELECT 1');
    console.log('✅ 数据库连接成功');

    // 检查表是否已存在
    const result = await pool.query(
      "SELECT EXISTS (SELECT 1 FROM information_schema.tables WHERE table_schema = 'public' AND table_name = 'users')"
    );

    if (result.rows[0].exists) {
      console.log('⚠️  数据库表已存在，跳过建表');
      console.log('如需重新初始化，请先清空数据库');
      await pool.end();
      return;
    }

    // 读取 SQL 文件
    const sqlFile = path.resolve(__dirname, '../database/init.sql');
    if (!fs.existsSync(sqlFile)) {
      console.error(`❌ 找不到 SQL 文件: ${sqlFile}`);
      await pool.end();
      process.exit(1);
    }

    console.log(`📄 读取 SQL 文件: ${sqlFile}`);
    const sql = fs.readFileSync(sqlFile, 'utf-8');

    // 执行 SQL
    const statements = sql.split(';').map(s => s.trim()).filter(s => s.length > 0);
    let executed = 0;

    for (const stmt of statements) {
      const clean = stmt.split('\n').filter(l => !l.trim().startsWith('--')).join('\n').trim();
      if (!clean) continue;

      try {
        await pool.query(clean);
        executed++;
      } catch (e: any) {
        if (e.code !== '42P07' && e.code !== '42710' && !e.message?.includes('already exists')) {
          console.warn(`⚠️  SQL 执行警告: ${e.message?.substring(0, 100)}`);
        }
      }
    }
    console.log(`✅ SQL 建表完成 (${executed} 条语句)`);

    // 创建默认用户
    console.log('👤 创建默认用户...');
    const users = [
      { phone: '181', name: '超级管理员', role: 'super_admin', password: '123456' },
      { phone: '110003199', name: '操作员', role: 'operator', password: '123456' },
    ];

    for (const u of users) {
      const hash = await bcrypt.hash(u.password, 12);
      try {
        await pool.query(
          'INSERT INTO users (phone, password_hash, name, role, status) VALUES ($1, $2, $3, $4, $5)',
          [u.phone, hash, u.name, u.role, 'active']
        );
        console.log(`  ✅ ${u.name} (${u.phone})`);
      } catch (e: any) {
        if (e.code === '23505') {
          console.log(`  ⏭️  ${u.name} 已存在，跳过`);
        } else {
          throw e;
        }
      }
    }

    // 生成库位
    console.log('📍 生成库位数据...');
    try {
      await pool.query('SELECT generate_storage_locations()');
      console.log('✅ 库位生成完成');
    } catch (e) {
      console.warn('⚠️  库位生成失败，可稍后手动处理');
    }

    console.log('');
    console.log('🎉 数据库初始化完成！');
    console.log('');
    console.log('默认账号:');
    console.log('  超级管理员: 181 / 123456');
    console.log('  操作员:     110003199 / 123456');
  } catch (e) {
    console.error('❌ 初始化失败:', e);
    process.exit(1);
  } finally {
    await pool.end();
  }
}

main();
